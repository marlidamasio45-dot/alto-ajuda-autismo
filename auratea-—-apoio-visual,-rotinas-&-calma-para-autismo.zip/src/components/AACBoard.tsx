import React, { useState, useEffect } from 'react';
import { 
  Volume2, 
  Trash2, 
  Delete, 
  Plus, 
  Search, 
  Sparkles, 
  Check, 
  X,
  Share2,
  Copy
} from 'lucide-react';
import { PictogramCard, PictogramCategory, UserPreferences } from '../types/autism';
import { DEFAULT_PICTOGRAMS } from '../data/autismData';
import { playSoftTap, speakText } from '../utils/audioEngine';

interface Props {
  preferences: UserPreferences;
}

const CATEGORIES: { id: PictogramCategory | 'all'; label: string; emoji: string }[] = [
  { id: 'all', label: 'Todos os Cards', emoji: '🌟' },
  { id: 'basic', label: 'Básicos & Expressão', emoji: '💬' },
  { id: 'food', label: 'Comidas & Bebidas', emoji: '🍎' },
  { id: 'emotions', label: 'Emoções & Sensações', emoji: '💛' },
  { id: 'body', label: 'Higiene & Corpo', emoji: '🧼' },
  { id: 'activities', label: 'Brincadeiras & Atividades', emoji: '🧸' },
  { id: 'places', label: 'Lugares & Pessoas', emoji: '🏠' },
];

const QUICK_PHRASES = [
  { text: 'Por favor, quero beber água', label: 'Quero água 💧' },
  { text: 'Estou com muita fome, quero comer', label: 'Estou com fome 🍽️' },
  { text: 'Por favor, preciso de ajuda agora', label: 'Preciso de ajuda 🆘' },
  { text: 'O barulho está muito alto, me incomoda', label: 'Muito barulho 🙉' },
  { text: 'Estou cansado, quero ir para casa', label: 'Quero ir para casa 🏠' },
  { text: 'Preciso ir ao banheiro agora', label: 'Quero ir ao banheiro 🚻' },
];

export const AACBoard: React.FC<Props> = ({ preferences }) => {
  // Load custom cards from localStorage
  const [cards, setCards] = useState<PictogramCard[]>(() => {
    try {
      const saved = localStorage.getItem('auratea_custom_cards');
      if (saved) {
        const parsed = JSON.parse(saved);
        return [...DEFAULT_PICTOGRAMS, ...parsed];
      }
    } catch {
      // fallback
    }
    return DEFAULT_PICTOGRAMS;
  });

  const [phrase, setPhrase] = useState<PictogramCard[]>([]);
  const [activeCategory, setActiveCategory] = useState<PictogramCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Form for custom card
  const [newLabel, setNewLabel] = useState('');
  const [newSpeech, setNewSpeech] = useState('');
  const [newEmoji, setNewEmoji] = useState('⭐');
  const [newCategory, setNewCategory] = useState<PictogramCategory>('basic');

  const filteredCards = cards.filter(card => {
    const matchesCategory = activeCategory === 'all' || card.category === activeCategory;
    const matchesSearch = card.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (card.speechText && card.speechText.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleAddCardToPhrase = (card: PictogramCard) => {
    playSoftTap(preferences.soundEnabled);
    setPhrase(prev => [...prev, card]);
    // Also read card if tapped
    speakText(card.speechText || card.label);
  };

  const handleRemoveLast = () => {
    playSoftTap(preferences.soundEnabled);
    setPhrase(prev => prev.slice(0, -1));
  };

  const handleClearPhrase = () => {
    playSoftTap(preferences.soundEnabled);
    setPhrase([]);
  };

  const handleSpeakPhrase = () => {
    if (phrase.length === 0) return;
    const fullText = phrase.map(c => c.speechText || c.label).join(' ');
    setIsSpeaking(true);
    speakText(fullText, () => {
      setIsSpeaking(false);
    });
  };

  const handleQuickPhrase = (text: string) => {
    playSoftTap(preferences.soundEnabled);
    setIsSpeaking(true);
    speakText(text, () => {
      setIsSpeaking(false);
    });
  };

  const handleSaveCustomCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLabel.trim()) return;

    const newCard: PictogramCard = {
      id: `custom_${Date.now()}`,
      label: newLabel.trim(),
      speechText: newSpeech.trim() || newLabel.trim(),
      category: newCategory,
      emoji: newEmoji.trim() || '⭐',
      bgTint: 'bg-emerald-50 text-emerald-950',
      borderTint: 'border-emerald-200',
      isCustom: true,
    };

    const nextCards = [...cards, newCard];
    setCards(nextCards);

    // Save only custom ones to storage
    const customList = nextCards.filter(c => c.isCustom);
    localStorage.setItem('auratea_custom_cards', JSON.stringify(customList));

    setNewLabel('');
    setNewSpeech('');
    setShowAddModal(false);
    playSoftTap(preferences.soundEnabled);
  };

  const handleCopyPhrase = () => {
    if (phrase.length === 0) return;
    const text = phrase.map(c => c.label).join(' ');
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Intro banner with calm illustration */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row items-center gap-6 justify-between">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 tracking-wide uppercase">
            <span>Comunicação Aumentativa e Alternativa (CAA)</span>
            <span>·</span>
            <span>Voz em Português</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Prancha de Comunicação Visual
          </h2>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Toque nos símbolos para montar frases e ouvir a fala instantaneamente. Crie autonomia diária para se comunicar sem barreiras.
          </p>
        </div>

        {/* Quick shortcut chips */}
        <div className="flex flex-wrap gap-2 justify-start md:justify-end shrink-0 w-full md:w-auto">
          <button
            onClick={() => setShowAddModal(true)}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Criar Meu Card</span>
          </button>
        </div>
      </div>

      {/* Phrase Builder Strip (Pinned visual focus) */}
      <div className="sticky top-[68px] z-20 bg-white/95 backdrop-blur-md rounded-2xl border-2 border-emerald-500/40 p-4 shadow-md transition-all">
        <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
            <span>Faixa de Frase</span>
            <span>·</span>
            <span>{phrase.length} {phrase.length === 1 ? 'símbolo' : 'símbolos'}</span>
          </div>

          <div className="flex items-center gap-1.5">
            {phrase.length > 0 && (
              <>
                <button
                  onClick={handleCopyPhrase}
                  className="min-h-[38px] px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg flex items-center gap-1 transition-colors"
                  title="Copiar texto da frase"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{copiedNotification ? 'Copiado!' : 'Copiar'}</span>
                </button>
                <button
                  onClick={handleRemoveLast}
                  className="min-h-[38px] px-2.5 py-1 text-xs font-medium text-amber-700 hover:bg-amber-50 rounded-lg flex items-center gap-1 transition-colors"
                  title="Apagar último símbolo"
                >
                  <Delete className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Voltar</span>
                </button>
                <button
                  onClick={handleClearPhrase}
                  className="min-h-[38px] px-2.5 py-1 text-xs font-medium text-rose-700 hover:bg-rose-50 rounded-lg flex items-center gap-1 transition-colors"
                  title="Limpar frase inteira"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Limpar</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Phrase Cards Container */}
        <div className="min-h-[76px] flex items-center gap-2 overflow-x-auto p-1.5 bg-slate-50/70 rounded-xl border border-slate-200/60 mb-3">
          {phrase.length === 0 ? (
            <div className="w-full text-center py-3 text-slate-400 text-xs sm:text-sm">
              Toque nos cartões abaixo para adicionar palavras à sua frase...
            </div>
          ) : (
            phrase.map((card, idx) => (
              <div
                key={`${card.id}-${idx}`}
                className="shrink-0 flex items-center gap-2 px-3 py-2 bg-white rounded-xl border border-emerald-300 shadow-xs animate-in fade-in duration-200"
              >
                <span className="text-2xl leading-none" aria-hidden="true">{card.emoji}</span>
                <span className="text-sm font-bold text-slate-900 whitespace-nowrap">{card.label}</span>
              </div>
            ))
          )}
        </div>

        {/* Speak Primary Action Button */}
        <button
          onClick={handleSpeakPhrase}
          disabled={phrase.length === 0 || isSpeaking}
          className={`w-full min-h-[50px] rounded-xl flex items-center justify-center gap-2 font-bold text-base transition-all ${
            phrase.length === 0
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
              : isSpeaking
              ? 'bg-emerald-700 text-white animate-pulse'
              : 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white shadow-sm'
          }`}
        >
          <Volume2 className={`w-5 h-5 ${isSpeaking ? 'animate-bounce' : ''}`} />
          <span>{isSpeaking ? 'Falando frase...' : 'Falar Frase Completa'}</span>
        </button>
      </div>

      {/* Quick SOS / Need Phrases Bar */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
          <span>Frases Rápidas de Emergência & Rotina</span>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {QUICK_PHRASES.map((qp, i) => (
            <button
              key={i}
              onClick={() => handleQuickPhrase(qp.text)}
              className="min-h-[44px] px-3.5 py-2 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-xs sm:text-sm font-semibold text-slate-700 hover:text-emerald-900 transition-colors shrink-0 flex items-center gap-1.5 shadow-2xs"
            >
              <Volume2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>{qp.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Category Filter and Search Toolbar */}
      <div className="space-y-3">
        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Buscar símbolo (ex: água, banheiro, fone, mãe, brincar)..."
            className="w-full min-h-[46px] pl-10 pr-4 py-2 bg-white rounded-xl border border-slate-200 text-slate-800 placeholder-slate-400 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setActiveCategory(cat.id);
              }}
              className={`min-h-[42px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                activeCategory === cat.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200/80'
              }`}
            >
              <span aria-hidden="true">{cat.emoji}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
        {filteredCards.map(card => (
          <button
            key={card.id}
            onClick={() => handleAddCardToPhrase(card)}
            className="min-h-[110px] p-3 rounded-2xl bg-white hover:bg-emerald-50/60 active:scale-[0.97] border-2 border-slate-200 hover:border-emerald-400 transition-all flex flex-col items-center justify-center text-center group shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
          >
            <span className="text-4xl mb-2 group-hover:scale-110 transition-transform select-none" aria-hidden="true">
              {card.emoji}
            </span>
            <span className="text-xs sm:text-sm font-bold text-slate-900 leading-tight line-clamp-2">
              {card.label}
            </span>
            {card.isCustom && (
              <span className="text-[10px] text-emerald-700 font-medium mt-1">Personalizado</span>
            )}
          </button>
        ))}
      </div>

      {filteredCards.length === 0 && (
        <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 p-6">
          <p className="text-base font-semibold text-slate-700 mb-2">Nenhum pictograma encontrado para "{searchQuery}"</p>
          <p className="text-sm text-slate-500 mb-4">Você pode criar este cartão facilmente com sua própria foto ou emoji.</p>
          <button
            onClick={() => {
              setNewLabel(searchQuery);
              setShowAddModal(true);
            }}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 text-white font-semibold text-sm hover:bg-emerald-700"
          >
            Criar Card "{searchQuery}"
          </button>
        </div>
      )}

      {/* Add Custom Card Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">Novo Card de Comunicação</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg min-h-[40px] min-w-[40px] flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomCard} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Emoji / Símbolo
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={newEmoji}
                    onChange={e => setNewEmoji(e.target.value)}
                    maxLength={3}
                    className="w-16 h-14 text-center text-3xl bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
                    placeholder="⭐"
                  />
                  <div className="flex-1 text-xs text-slate-500">
                    Insira o emoji que melhor representa a palavra (ex: 🥪, 🐶, 🎨, 🚌).
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nome do Card (Texto visível)
                </label>
                <input
                  type="text"
                  required
                  value={newLabel}
                  onChange={e => setNewLabel(e.target.value)}
                  placeholder="Ex: Pão de Queijo, Meu Cachorro, Desenho Animado"
                  className="w-full min-h-[44px] px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Pronúncia em Voz Alta (O que o app vai falar)
                </label>
                <input
                  type="text"
                  value={newSpeech}
                  onChange={e => setNewSpeech(e.target.value)}
                  placeholder="Ex: Quero comer pão de queijo quentinho"
                  className="w-full min-h-[44px] px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Categoria
                </label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as PictogramCategory)}
                  className="w-full min-h-[44px] px-3.5 py-2 bg-slate-50 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-500"
                >
                  <option value="basic">Básicos & Expressão</option>
                  <option value="food">Comidas & Bebidas</option>
                  <option value="emotions">Emoções & Sensações</option>
                  <option value="body">Higiene & Corpo</option>
                  <option value="activities">Brincadeiras & Atividades</option>
                  <option value="places">Lugares & Pessoas</option>
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold shadow-xs"
                >
                  Salvar Card
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
