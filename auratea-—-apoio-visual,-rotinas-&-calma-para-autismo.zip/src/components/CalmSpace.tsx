import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Square, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Wind, 
  Waves, 
  CloudRain, 
  Radio, 
  Bell, 
  RotateCcw,
  Sliders,
  Check
} from 'lucide-react';
import { UserPreferences } from '../types/autism';
import { playSoftTap, playBubblePop, soundscape, SoundscapeType } from '../utils/audioEngine';

interface Props {
  preferences: UserPreferences;
}

type BreathingTechnique = 'flower-candle' | 'box' | 'relax-478';

export const CalmSpace: React.FC<Props> = ({ preferences }) => {
  // Breathing guide state
  const [technique, setTechnique] = useState<BreathingTechnique>('flower-candle');
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathingPhase, setBreathingPhase] = useState<'inhale' | 'hold' | 'exhale' | 'hold-empty'>('inhale');
  const [countdown, setCountdown] = useState(4);

  // Soundscape state
  const [activeSound, setActiveSound] = useState<SoundscapeType>('none');
  const [soundVolume, setSoundVolume] = useState<number>(0.6);

  // Sensory Pop-it Fidget state (4x6 = 24 bubbles)
  const [poppedBubbles, setPoppedBubbles] = useState<boolean[]>(Array(24).fill(false));

  // Canvas ripple state
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Soundscape handler
  const handleToggleSound = (type: SoundscapeType) => {
    playSoftTap(preferences.soundEnabled);
    if (activeSound === type) {
      soundscape.stop();
      setActiveSound('none');
    } else {
      soundscape.play(type);
      soundscape.setVolume(soundVolume);
      setActiveSound(type);
    }
  };

  const handleVolumeChange = (vol: number) => {
    setSoundVolume(vol);
    soundscape.setVolume(vol);
  };

  // Breathing loop
  useEffect(() => {
    let timer: number;
    if (!breathingActive) {
      setCountdown(4);
      setBreathingPhase('inhale');
      return;
    }

    const runCycle = () => {
      if (technique === 'flower-candle') {
        // 4s Inhale (cheirar a flor), 4s Exhale (assoprar a vela)
        setBreathingPhase('inhale');
        setCountdown(4);
        timer = window.setTimeout(() => {
          setBreathingPhase('exhale');
          setCountdown(4);
          timer = window.setTimeout(runCycle, 4000);
        }, 4000);
      } else if (technique === 'box') {
        // 4s inhale, 4s hold, 4s exhale, 4s hold
        setBreathingPhase('inhale');
        setCountdown(4);
        timer = window.setTimeout(() => {
          setBreathingPhase('hold');
          setCountdown(4);
          timer = window.setTimeout(() => {
            setBreathingPhase('exhale');
            setCountdown(4);
            timer = window.setTimeout(() => {
              setBreathingPhase('hold-empty');
              setCountdown(4);
              timer = window.setTimeout(runCycle, 4000);
            }, 4000);
          }, 4000);
        }, 4000);
      } else {
        // 4-7-8
        setBreathingPhase('inhale');
        setCountdown(4);
        timer = window.setTimeout(() => {
          setBreathingPhase('hold');
          setCountdown(7);
          timer = window.setTimeout(() => {
            setBreathingPhase('exhale');
            setCountdown(8);
            timer = window.setTimeout(runCycle, 8000);
          }, 7000);
        }, 4000);
      }
    };

    runCycle();

    return () => {
      window.clearTimeout(timer);
    };
  }, [breathingActive, technique]);

  // Countdown second ticker
  useEffect(() => {
    if (!breathingActive) return;
    const interval = window.setInterval(() => {
      setCountdown(prev => (prev > 1 ? prev - 1 : 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [breathingActive, breathingPhase]);

  // Cleanup audio on unmount
  useEffect(() => {
    return () => {
      soundscape.stop();
    };
  }, []);

  // Pop-it bubble action
  const handleBubbleClick = (index: number) => {
    playBubblePop(preferences.soundEnabled);
    setPoppedBubbles(prev => {
      const next = [...prev];
      next[index] = !next[index];
      return next;
    });
  };

  const handleResetBubbles = () => {
    playSoftTap(preferences.soundEnabled);
    setPoppedBubbles(Array(24).fill(false));
  };

  // Interactive sensory ripples canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    interface Ripple {
      x: number;
      y: number;
      radius: number;
      opacity: number;
      color: string;
    }
    let ripples: Ripple[] = [];

    const colors = ['#10b981', '#38bdf8', '#a855f7', '#fbbf24', '#34d399'];

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ripples.forEach(r => {
        ctx.beginPath();
        ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
        ctx.strokeStyle = r.color;
        ctx.globalAlpha = r.opacity;
        ctx.lineWidth = 3;
        ctx.stroke();

        r.radius += 1.8;
        r.opacity -= 0.015;
      });

      ripples = ripples.filter(r => r.opacity > 0);
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    const addRipple = (e: MouseEvent | TouchEvent) => {
      const rect = canvas.getBoundingClientRect();
      let clientX = 0, clientY = 0;
      if ('touches' in e && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if ('clientX' in e) {
        clientX = e.clientX;
        clientY = e.clientY;
      }
      const x = clientX - rect.left;
      const y = clientY - rect.top;
      const color = colors[Math.floor(Math.random() * colors.length)];
      ripples.push({ x, y, radius: 10, opacity: 0.8, color });
      if (preferences.soundEnabled && Math.random() > 0.6) {
        playBubblePop(true);
      }
    };

    canvas.addEventListener('pointerdown', addRipple);
    canvas.addEventListener('pointermove', (e) => {
      if (e.buttons === 1) addRipple(e);
    });

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [preferences.soundEnabled]);

  const getPhaseInstruction = () => {
    if (technique === 'flower-candle') {
      if (breathingPhase === 'inhale') return '🌸 Cheire a flor pelo nariz...';
      return '🕯️ Assopre a vela bem devagar...';
    }
    if (breathingPhase === 'inhale') return 'Puxe o ar devagar pelo nariz';
    if (breathingPhase === 'hold') return 'Segure o ar com calma';
    if (breathingPhase === 'exhale') return 'Solte todo o ar pela boca';
    return 'Pausa serena...';
  };

  return (
    <div className="space-y-8">
      
      {/* Hero Zen Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-slate-200 bg-white shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center space-y-3 z-10">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider">
              <span>Espaço de Descompressão</span>
              <span>·</span>
              <span>Livre de Julgamentos</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Seu Refúgio Sensorial Seguro
            </h2>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl">
              Quando o mundo lá fora estiver barulhento ou acelerado demais, respire no seu próprio ritmo, ative sons reconfortantes e use ferramentas sensoriais para reorganizar seu corpo.
            </p>
          </div>

          <div className="lg:col-span-5 relative min-h-[200px] lg:min-h-full">
            <img
              src="/src/assets/images/sensory_calm_space_1792680377480.jpg"
              alt="Ambiente calmo sensorial com iluminação acolhedora"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-white via-white/40 to-transparent" />
          </div>

        </div>
      </div>

      {/* 1. GUIA DE RESPIRAÇÃO VISUAL SUAVE */}
      <section className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
              <span>Biofeedback Respiratório</span>
              <span>·</span>
              <span>Acalma o Nervo Vago</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Guia de Respiração Consciente
            </h3>
          </div>

          {/* Technique Picker */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto">
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setTechnique('flower-candle');
                setBreathingActive(false);
              }}
              className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors ${
                technique === 'flower-candle' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              🌸 Flor & Vela (4s/4s)
            </button>
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setTechnique('box');
                setBreathingActive(false);
              }}
              className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors ${
                technique === 'box' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              🟦 Quadrada (4-4-4-4)
            </button>
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setTechnique('relax-478');
                setBreathingActive(false);
              }}
              className={`min-h-[40px] px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors ${
                technique === 'relax-478' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              🧘 4-7-8 Profunda
            </button>
          </div>
        </div>

        {/* Breathing Animation Arena */}
        <div className="flex flex-col items-center justify-center py-6 sm:py-10">
          
          <div className="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
            {/* Outer animated soft halo */}
            <div
              className={`absolute inset-0 rounded-full transition-all ease-in-out ${
                breathingActive
                  ? breathingPhase === 'inhale'
                    ? 'scale-100 bg-emerald-200/50 duration-4000'
                    : breathingPhase === 'hold' || breathingPhase === 'hold-empty'
                    ? 'scale-95 bg-teal-200/40 duration-1000'
                    : 'scale-75 bg-slate-200/50 duration-4000'
                  : 'scale-85 bg-slate-100'
              }`}
            />

            {/* Inner focus sphere */}
            <div
              className={`w-44 h-44 sm:w-52 sm:h-52 rounded-full border-4 shadow-inner flex flex-col items-center justify-center text-center p-4 transition-all z-10 ${
                breathingPhase === 'inhale'
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-950 scale-105'
                  : breathingPhase === 'hold' || breathingPhase === 'hold-empty'
                  ? 'border-teal-500 bg-teal-50 text-teal-950 scale-100'
                  : 'border-slate-400 bg-white text-slate-800 scale-95'
              }`}
            >
              <span className="text-3xl sm:text-4xl font-mono font-black mb-1">
                {breathingActive ? countdown : '—'}
              </span>
              <span className="text-xs sm:text-sm font-bold leading-tight">
                {breathingActive ? getPhaseInstruction() : 'Toque em Começar'}
              </span>
            </div>
          </div>

          {/* Action Trigger */}
          <div className="mt-8 flex items-center gap-3">
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setBreathingActive(prev => !prev);
              }}
              className={`min-h-[48px] px-8 py-2.5 rounded-2xl font-bold text-sm sm:text-base flex items-center gap-2 shadow-sm transition-all ${
                breathingActive
                  ? 'bg-amber-600 hover:bg-amber-700 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              {breathingActive ? (
                <>
                  <Square className="w-5 h-5 fill-current" />
                  <span>Pausar Respiração</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  <span>Começar Respiração Guiada</span>
                </>
              )}
            </button>
          </div>
        </div>
      </section>

      {/* 2. PAISAGENS SONORAS RELAXANTES (Web Audio API Synthesizer) */}
      <section className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
              <span>Sons Contínuos Sem Cortes</span>
              <span>·</span>
              <span>Abafador Auditivo</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Sons Relaxantes & Ruído Branco/Marrom
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              O ruído marrom e os sons da natureza filtram estímulos externos repentinos e tranquilizam o sistema nervoso.
            </p>
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-2 bg-slate-50 px-3.5 py-2 rounded-xl border border-slate-200">
            <Volume2 className="w-4 h-4 text-slate-500" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={soundVolume}
              onChange={e => handleVolumeChange(parseFloat(e.target.value))}
              className="w-24 accent-emerald-600"
              aria-label="Volume dos sons"
            />
            <span className="text-xs font-mono font-semibold text-slate-600 w-8 text-right">
              {Math.round(soundVolume * 100)}%
            </span>
          </div>
        </div>

        {/* Sound buttons grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {[
            { id: 'brown-noise' as SoundscapeType, label: 'Ruído Marrom', sub: 'O favorito no TEA', emoji: '📻', icon: Radio },
            { id: 'rain' as SoundscapeType, label: 'Chuva Suave', sub: 'Gotas na janela', emoji: '🌧️', icon: CloudRain },
            { id: 'ocean' as SoundscapeType, label: 'Ondas do Mar', sub: 'Ritmo oceânico', emoji: '🌊', icon: Waves },
            { id: 'tibetan-bowl' as SoundscapeType, label: 'Sino Tibetano', sub: 'Harmônicos de paz', emoji: '🔔', icon: Bell },
            { id: 'stream' as SoundscapeType, label: 'Riacho de Água', sub: 'Água corrente', emoji: '🍃', icon: Wind },
          ].map(sound => {
            const isPlaying = activeSound === sound.id;
            return (
              <button
                key={sound.id}
                onClick={() => handleToggleSound(sound.id)}
                className={`min-h-[110px] p-4 rounded-2xl border-2 transition-all flex flex-col items-center justify-center text-center ${
                  isPlaying
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-950 shadow-xs scale-102'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span className="text-3xl mb-1.5" aria-hidden="true">{sound.emoji}</span>
                <span className="text-sm font-bold leading-tight">{sound.label}</span>
                <span className="text-[11px] text-slate-500 mt-0.5">{sound.sub}</span>
                {isPlaying && (
                  <span className="mt-2 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping" /> Tocando
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {activeSound !== 'none' && (
          <div className="mt-4 flex justify-end">
            <button
              onClick={() => handleToggleSound(activeSound)}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 px-3 py-1.5 rounded-lg hover:bg-rose-50 transition-colors flex items-center gap-1"
            >
              <VolumeX className="w-4 h-4" /> Desligar som
            </button>
          </div>
        )}
      </section>

      {/* 3. BRINQUEDO SENSORIAL FIDGET (Pop-it & Ripple Canvas) */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Pop-it Virtual */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider">
                <span>Fidget Sensorial Tátil</span>
              </div>
              <button
                onClick={handleResetBubbles}
                className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Restaurar todas
              </button>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              Placa de Bolhas (Pop-it Anti-stress)
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Toque nas bolhas para estourá-las com som suave e sensação de alívio tátil.
            </p>

            {/* Bubble matrix */}
            <div className="grid grid-cols-6 gap-2.5 p-3.5 bg-slate-100/80 rounded-2xl border border-slate-200">
              {poppedBubbles.map((popped, idx) => (
                <button
                  key={idx}
                  onClick={() => handleBubbleClick(idx)}
                  className={`w-full aspect-square rounded-full transition-all duration-150 flex items-center justify-center shadow-xs ${
                    popped
                      ? 'bg-slate-300 scale-90 inset-shadow-sm border-2 border-slate-400/50'
                      : 'bg-emerald-400 hover:bg-emerald-300 active:scale-95 shadow-md shadow-emerald-500/20 border-2 border-emerald-500'
                  }`}
                  aria-label={`Bolha ${idx + 1}`}
                >
                  <span className={`w-2 h-2 rounded-full ${popped ? 'bg-slate-400/50' : 'bg-emerald-100/80'}`} />
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 text-center text-xs text-slate-500 font-medium">
            {poppedBubbles.filter(Boolean).length} de {poppedBubbles.length} bolhas estouradas
          </div>
        </div>

        {/* Ripple Sensory Canvas */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-2">
              <span>Estimulação Visual Suave</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              Ondas de Luz Sensoriais
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Toque ou passe o dedo no quadro abaixo para criar ondulações tranquilas de cores suaves.
            </p>

            <div className="relative w-full h-52 sm:h-56 bg-slate-900 rounded-2xl overflow-hidden cursor-crosshair">
              <canvas
                ref={canvasRef}
                width={450}
                height={230}
                className="w-full h-full touch-none"
              />
              <div className="absolute bottom-2 left-3 text-[10px] text-slate-400 pointer-events-none">
                Toque na tela para criar círculos relaxantes
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
            <span>Efeito calmante para foco visual</span>
            <span className="font-mono">Toque contínuo</span>
          </div>
        </div>

      </section>

    </div>
  );
};
