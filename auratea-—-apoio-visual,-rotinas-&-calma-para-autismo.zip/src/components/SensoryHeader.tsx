import React from 'react';
import { 
  HeartHandshake, 
  Settings, 
  ShieldAlert, 
  Volume2, 
  VolumeX, 
  Sparkles,
  MessageSquare,
  CalendarCheck,
  Wind,
  Smile,
  BookOpen
} from 'lucide-react';
import { UserPreferences } from '../types/autism';
import { playSoftTap } from '../utils/audioEngine';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  preferences: UserPreferences;
  setPreferences: React.Dispatch<React.SetStateAction<UserPreferences>>;
  onOpenSettings: () => void;
  onOpenEmergency: () => void;
}

export const SensoryHeader: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  preferences,
  setPreferences,
  onOpenSettings,
  onOpenEmergency
}) => {
  const toggleSound = () => {
    const next = !preferences.soundEnabled;
    setPreferences(prev => ({ ...prev, soundEnabled: next }));
    if (next) {
      playSoftTap(true);
    }
  };

  const navItems = [
    { id: 'aac', label: 'Comunicação (CAA)', icon: MessageSquare },
    { id: 'routines', label: 'Rotinas & Visual', icon: CalendarCheck },
    { id: 'calm', label: 'Espaço de Calma', icon: Wind },
    { id: 'emotions', label: 'Termômetro Emocional', icon: Smile },
    { id: 'stories', label: 'Histórias Sociais', icon: BookOpen },
  ];

  return (
    <header className="sticky top-0 z-30 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          
          {/* Zone 1: Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setActiveTab('aac');
              }}
              className="flex items-center gap-2.5 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg p-1"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-sm shadow-emerald-700/20 group-hover:scale-105 transition-transform">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-1.5">
                  AuraTEA
                </span>
                <span className="block text-[11px] font-medium text-slate-500 -mt-0.5">
                  Apoio Visual & Sensorial
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    playSoftTap(preferences.soundEnabled);
                    setActiveTab(item.id);
                  }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap min-h-[44px] ${
                    isActive
                      ? 'bg-emerald-50 text-emerald-800 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-700' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions & Emergency SOS */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Audio Mute/Unmute */}
            <button
              onClick={toggleSound}
              title={preferences.soundEnabled ? 'Silenciar sons do app' : 'Ativar sons suaves'}
              className="min-h-[44px] min-w-[44px] p-2.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              aria-label={preferences.soundEnabled ? 'Desativar sons' : 'Ativar sons'}
            >
              {preferences.soundEnabled ? (
                <Volume2 className="w-5 h-5 text-emerald-700" />
              ) : (
                <VolumeX className="w-5 h-5 text-slate-400" />
              )}
            </button>

            {/* Accessibility / Theme Settings */}
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                onOpenSettings();
              }}
              title="Ajustes de Acessibilidade e Cores"
              className="min-h-[44px] min-w-[44px] p-2.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
              aria-label="Configurações sensoriais"
            >
              <Settings className="w-5 h-5" />
            </button>

            {/* Emergency SOS Passaporte Card */}
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                onOpenEmergency();
              }}
              className="min-h-[44px] px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-[0.98] text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-sm transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 whitespace-nowrap"
            >
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">Cartão de Emergência</span>
              <span className="sm:hidden">SOS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Horizontal Navigation Bar */}
      <div className="md:hidden border-t border-slate-200/80 px-2 py-1.5 flex items-center justify-around overflow-x-auto gap-1">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                setActiveTab(item.id);
              }}
              className={`flex flex-col items-center justify-center min-w-[62px] min-h-[46px] p-1 rounded-lg text-[11px] transition-colors ${
                isActive
                  ? 'bg-emerald-50 text-emerald-800 font-semibold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className={`w-4 h-4 mb-0.5 ${isActive ? 'text-emerald-700' : 'text-slate-400'}`} />
              <span className="truncate max-w-[70px]">{item.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
