import React, { useState } from 'react';
import { 
  BookOpen, 
  ArrowLeft, 
  ArrowRight, 
  Volume2, 
  Sparkles, 
  Check, 
  Lightbulb,
  Heart
} from 'lucide-react';
import { SocialStory, UserPreferences } from '../types/autism';
import { SOCIAL_STORIES } from '../data/autismData';
import { playSoftTap, speakText } from '../utils/audioEngine';

interface Props {
  preferences: UserPreferences;
}

export const SocialStoriesView: React.FC<Props> = ({ preferences }) => {
  const [selectedStoryId, setSelectedStoryId] = useState<string | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  const selectedStory = SOCIAL_STORIES.find(s => s.id === selectedStoryId);

  const handleOpenStory = (id: string) => {
    playSoftTap(preferences.soundEnabled);
    setSelectedStoryId(id);
    setCurrentStepIndex(0);
  };

  const handleBackToGallery = () => {
    playSoftTap(preferences.soundEnabled);
    setSelectedStoryId(null);
    setCurrentStepIndex(0);
  };

  const handleNextStep = () => {
    if (!selectedStory) return;
    if (currentStepIndex < selectedStory.steps.length - 1) {
      playSoftTap(preferences.soundEnabled);
      setCurrentStepIndex(prev => prev + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      playSoftTap(preferences.soundEnabled);
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  const handleSpeakCurrentStep = () => {
    if (!selectedStory) return;
    const step = selectedStory.steps[currentStepIndex];
    speakText(`${step.title}. ${step.description}`);
  };

  return (
    <div className="space-y-6">
      
      {!selectedStory ? (
        // Story Selection Gallery
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
              <span>Histórias Sociais de Carol Gray</span>
              <span>·</span>
              <span>Previsibilidade</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Histórias Sociais Passo a Passo
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-3xl leading-relaxed">
              Narrativas visuais para entender situações novas ou desafiadoras antes que elas aconteçam, diminuindo a ansiedade e validando os sentimentos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SOCIAL_STORIES.map(story => (
              <div
                key={story.id}
                onClick={() => handleOpenStory(story.id)}
                className="p-6 rounded-3xl bg-white hover:bg-emerald-50/40 border-2 border-slate-200 hover:border-emerald-300 transition-all cursor-pointer shadow-xs group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-4xl select-none" aria-hidden="true">{story.emoji}</span>
                    <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                      {story.steps.length} passos
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-950 transition-colors">
                    {story.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                    {story.summary}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-emerald-700">
                  <span>Abrir História</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        // Active Story Interactive Reader
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          
          {/* Top Bar with back button */}
          <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <button
              onClick={handleBackToGallery}
              className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs sm:text-sm font-semibold text-slate-700 flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Ver Todas as Histórias</span>
            </button>

            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-slate-500">
                Passo {currentStepIndex + 1} de {selectedStory.steps.length}
              </span>
            </div>
          </div>

          {/* Progress dots */}
          <div className="flex items-center gap-2 justify-center">
            {selectedStory.steps.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  playSoftTap(preferences.soundEnabled);
                  setCurrentStepIndex(idx);
                }}
                className={`h-2.5 rounded-full transition-all ${
                  idx === currentStepIndex
                    ? 'w-8 bg-emerald-600'
                    : idx < currentStepIndex
                    ? 'w-2.5 bg-emerald-300'
                    : 'w-2.5 bg-slate-200'
                }`}
                aria-label={`Ir para passo ${idx + 1}`}
              />
            ))}
          </div>

          {/* Active Step Card */}
          {(() => {
            const step = selectedStory.steps[currentStepIndex];
            const isLastStep = currentStepIndex === selectedStory.steps.length - 1;

            return (
              <div className="p-6 sm:p-8 rounded-3xl bg-slate-50/70 border border-slate-200 space-y-5 animate-in fade-in duration-200">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-4xl sm:text-5xl shadow-xs shrink-0 select-none">
                    {step.emoji}
                  </div>

                  <button
                    onClick={handleSpeakCurrentStep}
                    className="min-h-[44px] px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-700 flex items-center gap-1.5 shadow-2xs transition-colors shrink-0"
                    title="Ouvir leitura em voz alta"
                  >
                    <Volume2 className="w-4 h-4 text-emerald-600" />
                    <span>Ler Passo</span>
                  </button>
                </div>

                <div>
                  <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                    {step.title}
                  </h3>
                  <p className="text-base sm:text-lg text-slate-700 leading-relaxed mt-2">
                    {step.description}
                  </p>
                </div>

                {step.tips && (
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-start gap-3">
                    <Lightbulb className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                    <div className="text-xs sm:text-sm text-emerald-950 font-medium leading-relaxed">
                      <span className="font-bold block">Dica Sensorial & Acolhimento:</span>
                      {step.tips}
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="pt-4 flex items-center justify-between gap-3">
                  <button
                    onClick={handlePrevStep}
                    disabled={currentStepIndex === 0}
                    className={`min-h-[46px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                      currentStepIndex === 0
                        ? 'opacity-40 cursor-not-allowed text-slate-400'
                        : 'text-slate-700 hover:bg-slate-200/80 bg-white border border-slate-200'
                    }`}
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Passo Anterior</span>
                  </button>

                  {isLastStep ? (
                    <button
                      onClick={handleBackToGallery}
                      className="min-h-[46px] px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-xs transition-colors"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Concluir História</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleNextStep}
                      className="min-h-[46px] px-6 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-xs transition-colors"
                    >
                      <span>Próximo Passo</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })()}

        </div>
      )}

    </div>
  );
};
