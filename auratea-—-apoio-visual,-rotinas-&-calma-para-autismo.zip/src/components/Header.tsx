import React, { useState } from 'react';
import { Sparkles, Menu, X } from 'lucide-react';

interface HeaderProps {
  onOpenWizard: () => void;
  activeSection: string;
}

export const Header: React.FC<HeaderProps> = ({ onOpenWizard }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800 bg-neutral-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark (single text element, no subtitle pills) */}
        <a 
          href="#" 
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-sm bg-amber-400"></span>
          <span>Radar IA</span>
        </a>

        {/* Zone 2: 4-5 clean single-line nav links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-400">
          <a href="#podio" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            O Pódio
          </a>
          <a href="#explorar" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Explorar
          </a>
          <a href="#comparador" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Comparador
          </a>
          <a href="#stacks" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Stacks
          </a>
          <a href="#prompts" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Prompts
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenWizard}
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Descobrir Minha IA</span>
          </button>

          {/* Mobile hamburger toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-neutral-400 hover:text-white rounded-md border border-neutral-800"
            aria-label="Abrir menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-neutral-800 bg-neutral-950 px-4 pt-3 pb-5 space-y-3">
          <nav className="flex flex-col space-y-2 text-sm font-medium text-neutral-300">
            <a 
              href="#podio" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-neutral-900 hover:text-white"
            >
              O Pódio das Campeãs
            </a>
            <a 
              href="#explorar" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-neutral-900 hover:text-white"
            >
              Explorar Todas as IAs
            </a>
            <a 
              href="#comparador" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-neutral-900 hover:text-white"
            >
              Comparador Lado a Lado
            </a>
            <a 
              href="#stacks" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-neutral-900 hover:text-white"
            >
              Stacks Completos
            </a>
            <a 
              href="#prompts" 
              onClick={() => setMobileMenuOpen(false)}
              className="px-2 py-1.5 rounded hover:bg-neutral-900 hover:text-white"
            >
              Guia de Prompts
            </a>
          </nav>
          <div className="pt-2 border-t border-neutral-800">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenWizard();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Descobrir Minha IA</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
