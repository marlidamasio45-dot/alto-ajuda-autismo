import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  Phone, 
  Edit3, 
  Check, 
  Printer, 
  Maximize2, 
  Minimize2, 
  Heart, 
  AlertTriangle,
  Info
} from 'lucide-react';
import { EmergencyPassport, UserPreferences } from '../types/autism';
import { DEFAULT_EMERGENCY_PASSPORT } from '../data/autismData';
import { playSoftTap } from '../utils/audioEngine';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserPreferences;
}

export const EmergencyCardModal: React.FC<Props> = ({ isOpen, onClose, preferences }) => {
  const [passport, setPassport] = useState<EmergencyPassport>(() => {
    try {
      const saved = localStorage.getItem('auratea_emergency_passport');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return DEFAULT_EMERGENCY_PASSPORT;
  });

  const [isEditing, setIsEditing] = useState(false);
  const [isFullscreenMode, setIsFullscreenMode] = useState(false);

  // Edit form states
  const [formData, setFormData] = useState<EmergencyPassport>(passport);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    playSoftTap(preferences.soundEnabled);
    setPassport(formData);
    localStorage.setItem('auratea_emergency_passport', JSON.stringify(formData));
    setIsEditing(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div 
        className={`bg-white rounded-3xl shadow-2xl border-2 border-rose-300 w-full transition-all duration-200 overflow-hidden ${
          isFullscreenMode ? 'max-w-4xl p-6 sm:p-10 my-auto' : 'max-w-2xl p-6 my-8'
        }`}
      >
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 leading-tight">
                Cartão de Apoio & Identificação Sensorial
              </h3>
              <span className="text-xs text-slate-500">
                Apresente em caso de emergência ou sobrecarga
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsFullscreenMode(!isFullscreenMode)}
              title={isFullscreenMode ? 'Sair do modo tela cheia' : 'Modo exibição grande'}
              className="p-2 text-slate-600 hover:text-slate-900 rounded-lg min-h-[40px] min-w-[40px] flex items-center justify-center hover:bg-slate-100"
            >
              {isFullscreenMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={handlePrint}
              title="Imprimir cartão físico"
              className="p-2 text-slate-600 hover:text-slate-900 rounded-lg min-h-[40px] min-w-[40px] flex items-center justify-center hover:bg-slate-100"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                onClose();
              }}
              className="p-2 text-slate-400 hover:text-slate-700 rounded-lg min-h-[40px] min-w-[40px] flex items-center justify-center hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="mt-4">
          {!isEditing ? (
            // DISPLAY CARD VIEW
            <div className="space-y-5">
              
              {/* Official Alert Banner */}
              <div className="p-4 rounded-2xl bg-rose-50 border-2 border-rose-200 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-rose-600 text-white flex items-center justify-center text-xl shrink-0 font-black">
                  TEA
                </div>
                <div>
                  <h4 className="text-base sm:text-lg font-black text-rose-950 uppercase tracking-tight">
                    SOU UMA PESSOA NO ESPECTRO AUTISTA (TEA)
                  </h4>
                  <p className="text-xs sm:text-sm text-rose-900 leading-snug">
                    Lei Federal nº 12.764/12 (Lei Berenice Piana). Posso apresentar sobrecarga sensorial e necessitar de tempo e espaço.
                  </p>
                </div>
              </div>

              {/* Personal Identification */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                <div>
                  <span className="text-[11px] font-bold text-slate-500 uppercase block">Nome</span>
                  <span className="text-base font-bold text-slate-900">{passport.personName}</span>
                  {passport.preferredName && (
                    <span className="text-xs text-slate-500 block">Prefiro ser chamado de: {passport.preferredName}</span>
                  )}
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-500 uppercase block">Idade</span>
                  <span className="text-base font-bold text-slate-900">{passport.birthYearOrAge}</span>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-500 uppercase block">Perfil de Fala</span>
                  <span className="text-sm font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-md inline-block mt-0.5">
                    {passport.isVerbal === 'verbal' ? 'Verbal' : passport.isVerbal === 'semi-verbal' ? 'Semi-Verbal / Flutuante' : 'Não-Verbal'}
                  </span>
                </div>
              </div>

              {/* Communication Guidance */}
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200">
                <span className="text-xs font-black uppercase text-amber-900 tracking-wider flex items-center gap-1.5 mb-1">
                  <Info className="w-3.5 h-3.5 text-amber-700" />
                  Como se comunicar comigo agora
                </span>
                <p className="text-xs sm:text-sm text-amber-950 leading-relaxed font-medium">
                  {passport.communicationTip}
                </p>
              </div>

              {/* Emergency Contact Clickable Card */}
              <div className="p-4 rounded-2xl bg-white border-2 border-emerald-400 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                <div>
                  <span className="text-[11px] font-bold text-emerald-800 uppercase block">
                    Contato de Emergência Principal
                  </span>
                  <span className="text-base font-bold text-slate-900">
                    {passport.emergencyContactName}
                  </span>
                  <span className="text-sm text-slate-600 block">
                    {passport.emergencyPhone}
                  </span>
                </div>

                <a
                  href={`tel:${passport.emergencyPhone.replace(/\D/g, '')}`}
                  className="min-h-[44px] px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors shrink-0"
                >
                  <Phone className="w-4 h-4 fill-current" />
                  <span>Ligar para Contato</span>
                </a>
              </div>

              {/* Sensory sensitivities & Calming techniques */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Triggers */}
                <div className="p-4 rounded-2xl bg-rose-50/40 border border-rose-200 space-y-2">
                  <span className="text-xs font-bold uppercase text-rose-900 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                    Gatilhos Sensoriais Comuns
                  </span>
                  <ul className="space-y-1 text-xs text-rose-950">
                    {passport.sensoryTriggers.map((t, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-rose-500 font-bold">•</span>
                        <span>{t}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Calming */}
                <div className="p-4 rounded-2xl bg-emerald-50/40 border border-emerald-200 space-y-2">
                  <span className="text-xs font-bold uppercase text-emerald-900 flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-emerald-600" />
                    O que ajuda a me acalmar
                  </span>
                  <ul className="space-y-1 text-xs text-emerald-950">
                    {passport.calmingTips.map((c, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-emerald-500 font-bold">•</span>
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Special Interest & Medical */}
              <div className="text-xs text-slate-500 space-y-1 pt-1">
                <p><strong>Hiperfoco de conforto:</strong> {passport.safeSpecialInterests}</p>
                <p><strong>Observações de saúde:</strong> {passport.hasMedicalNotes}</p>
              </div>

              {/* Bottom buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => {
                    setFormData(passport);
                    setIsEditing(true);
                  }}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 flex items-center gap-1.5 transition-colors"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Personalizar Dados</span>
                </button>

                <button
                  onClick={onClose}
                  className="min-h-[44px] px-6 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs sm:text-sm hover:bg-slate-800 transition-colors"
                >
                  Fechar
                </button>
              </div>

            </div>
          ) : (
            // EDIT FORM VIEW
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nome Completo</label>
                  <input
                    type="text"
                    required
                    value={formData.personName}
                    onChange={e => setFormData({ ...formData, personName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Como prefere ser chamado</label>
                  <input
                    type="text"
                    value={formData.preferredName || ''}
                    onChange={e => setFormData({ ...formData, preferredName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Idade</label>
                  <input
                    type="text"
                    value={formData.birthYearOrAge}
                    onChange={e => setFormData({ ...formData, birthYearOrAge: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Perfil de Fala</label>
                  <select
                    value={formData.isVerbal}
                    onChange={e => setFormData({ ...formData, isVerbal: e.target.value as 'verbal' | 'semi-verbal' | 'non-verbal' })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                  >
                    <option value="verbal">Verbal</option>
                    <option value="semi-verbal">Semi-verbal (fala flutua com estresse)</option>
                    <option value="non-verbal">Não-verbal (uso CAA / gestos)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nome do Contato de Emergência</label>
                  <input
                    type="text"
                    required
                    value={formData.emergencyContactName}
                    onChange={e => setFormData({ ...formData, emergencyContactName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Telefone de Emergência</label>
                  <input
                    type="text"
                    required
                    value={formData.emergencyPhone}
                    onChange={e => setFormData({ ...formData, emergencyPhone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Instrução de Comunicação</label>
                <textarea
                  rows={2}
                  value={formData.communicationTip}
                  onChange={e => setFormData({ ...formData, communicationTip: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl"
                >
                  Salvar Informações
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
