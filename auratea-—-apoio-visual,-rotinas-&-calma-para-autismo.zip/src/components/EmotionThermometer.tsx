import React, { useState } from 'react';
import { 
  Smile, 
  AlertCircle, 
  Flame, 
  ShieldAlert, 
  CheckCircle2, 
  Volume2, 
  Save, 
  Clock, 
  Sparkles,
  Heart
} from 'lucide-react';
import { RegulationZone, RegulationZoneInfo, UserPreferences } from '../types/autism';
import { REGULATION_ZONES } from '../data/autismData';
import { playSoftTap, speakText } from '../utils/audioEngine';

interface Props {
  preferences: UserPreferences;
  onNavigateToCalm: () => void;
}

interface EmotionLogEntry {
  id: string;
  zone: RegulationZone;
  zoneName: string;
  feeling: string;
  timestamp: string;
  note?: string;
}

export const EmotionThermometer: React.FC<Props> = ({ preferences, onNavigateToCalm }) => {
  const [selectedZone, setSelectedZone] = useState<RegulationZone>('green');
  const [userNote, setUserNote] = useState('');
  const [logs, setLogs] = useState<EmotionLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem('auratea_emotion_logs');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: 'log_init',
        zone: 'green',
        zoneName: 'Zona Verde',
        feeling: 'Calmo, Conectado & Focado',
        timestamp: 'Hoje, 09:00'
      }
    ];
  });
  const [justSaved, setJustSaved] = useState(false);

  const activeZoneInfo = REGULATION_ZONES.find(z => z.zone === selectedZone) || REGULATION_ZONES[0];

  const handleSelectZone = (zone: RegulationZone) => {
    playSoftTap(preferences.soundEnabled);
    setSelectedZone(zone);
  };

  const handleSpeakStatus = () => {
    const text = `Eu estou na ${activeZoneInfo.name}. Me sinto ${activeZoneInfo.feeling}. Por favor, me ajude com paciência.`;
    speakText(text);
  };

  const handleSaveLog = (e: React.FormEvent) => {
    e.preventDefault();
    playSoftTap(preferences.soundEnabled);

    const now = new Date();
    const formatted = now.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });

    const newEntry: EmotionLogEntry = {
      id: `log_${Date.now()}`,
      zone: selectedZone,
      zoneName: activeZoneInfo.name,
      feeling: activeZoneInfo.feeling,
      timestamp: formatted,
      note: userNote.trim() || undefined,
    };

    const nextLogs = [newEntry, ...logs.slice(0, 14)]; // keep last 15
    setLogs(nextLogs);
    localStorage.setItem('auratea_emotion_logs', JSON.stringify(nextLogs));
    setUserNote('');
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 2500);
  };

  return (
    <div className="space-y-8">
      
      {/* Intro Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
          <span>Zones of Regulation</span>
          <span>·</span>
          <span>Autorreconhecimento</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          Termômetro Emocional & Nível de Sobrecarga
        </h2>
        <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-3xl leading-relaxed">
          Reconhecer como o corpo está se sentindo antes de atingir o limite é um superpoder. Escolha sua zona atual para ver estratégias imediatas de conforto.
        </p>

        {/* 4 Interactive Big Zones */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mt-6">
          {REGULATION_ZONES.map(z => {
            const isSelected = selectedZone === z.zone;
            return (
              <button
                key={z.zone}
                onClick={() => handleSelectZone(z.zone)}
                className={`min-h-[140px] p-4 rounded-2xl border-2 transition-all flex flex-col items-center justify-between text-center ${
                  isSelected
                    ? `${z.bgClass} ${z.borderClass} scale-102 shadow-md ring-2 ring-slate-900/10`
                    : 'bg-white hover:bg-slate-50 border-slate-200 opacity-80 hover:opacity-100'
                }`}
              >
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl bg-white/80 shadow-2xs">
                  {z.zone === 'green' && '🟢'}
                  {z.zone === 'yellow' && '🟡'}
                  {z.zone === 'orange' && '🟠'}
                  {z.zone === 'red' && '🔴'}
                </div>

                <div className="mt-2">
                  <span className="block text-sm font-bold text-slate-900">{z.name}</span>
                  <span className="block text-[11px] text-slate-600 line-clamp-1 mt-0.5">{z.feeling.split(',')[0]}</span>
                </div>

                {isSelected ? (
                  <span className="text-[10px] font-black uppercase text-slate-900 bg-white/90 px-2.5 py-0.5 rounded-full mt-2">
                    Selecionado
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-400 mt-2">Toque para ver</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Zone Deep Dive */}
      <div className={`rounded-3xl border-2 p-6 sm:p-8 transition-colors ${activeZoneInfo.bgClass} ${activeZoneInfo.borderClass}`}>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-black/10">
          <div>
            <span className="text-xs font-black uppercase tracking-wider opacity-75">
              Estado Atual Selecionado
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold tracking-tight mt-0.5">
              {activeZoneInfo.name} — {activeZoneInfo.feeling}
            </h3>
            <p className="text-sm opacity-90 mt-1 max-w-2xl leading-relaxed">
              {activeZoneInfo.description}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {/* Speak aloud button */}
            <button
              onClick={handleSpeakStatus}
              className="min-h-[44px] px-4 py-2 bg-white/90 hover:bg-white text-slate-900 font-bold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-xs transition-colors"
            >
              <Volume2 className="w-4 h-4 text-emerald-700" />
              <span>Falar em Voz Alta</span>
            </button>

            {/* Quick Calm Room button */}
            {(selectedZone === 'orange' || selectedZone === 'red' || selectedZone === 'yellow') && (
              <button
                onClick={onNavigateToCalm}
                className="min-h-[44px] px-4 py-2 bg-slate-900 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center gap-2 shadow-xs hover:bg-slate-800 transition-colors"
              >
                <Heart className="w-4 h-4 text-rose-400" />
                <span>Ir para Espaço de Calma</span>
              </button>
            )}
          </div>
        </div>

        {/* Recommended Strategies */}
        <div className="mt-6">
          <h4 className="text-sm font-bold uppercase tracking-wider mb-3 opacity-90">
            Estratégias Concretas de Autorregulação
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {activeZoneInfo.recommendedStrategies.map((strat, i) => (
              <div
                key={i}
                className="p-4 rounded-2xl bg-white/90 border border-black/5 shadow-2xs space-y-1"
              >
                <div className="flex items-center gap-2">
                  <span className="text-2xl" aria-hidden="true">{strat.emoji}</span>
                  <span className="text-sm font-bold text-slate-900">{strat.title}</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed pt-1">
                  {strat.actionText}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Check-in save form */}
        <form onSubmit={handleSaveLog} className="mt-6 pt-5 border-t border-black/10 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <input
            type="text"
            value={userNote}
            onChange={e => setUserNote(e.target.value)}
            placeholder="O que causou essa sensação? (ex: luz forte no shopping, sono, barulho da obra)..."
            className="flex-1 min-h-[44px] px-4 py-2 bg-white/90 rounded-xl border border-black/10 text-xs sm:text-sm placeholder-slate-500 text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
          />
          <button
            type="submit"
            className="min-h-[44px] px-5 py-2 bg-slate-900 text-white text-xs sm:text-sm font-bold rounded-xl flex items-center justify-center gap-2 shrink-0 hover:bg-slate-800 shadow-2xs"
          >
            {justSaved ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Registrado com Sucesso!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Salvar no Histórico</span>
              </>
            )}
          </button>
        </form>

      </div>

      {/* History Log Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <h3 className="text-base font-bold text-slate-900">
              Histórico Recente de Check-ins Emocionais
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">Últimos registros</span>
        </div>

        <div className="space-y-2">
          {logs.map((log) => (
            <div
              key={log.id}
              className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 flex items-center justify-between gap-3 text-xs sm:text-sm"
            >
              <div className="flex items-center gap-3">
                <span className="text-lg">
                  {log.zone === 'green' && '🟢'}
                  {log.zone === 'yellow' && '🟡'}
                  {log.zone === 'orange' && '🟠'}
                  {log.zone === 'red' && '🔴'}
                </span>
                <div>
                  <span className="font-bold text-slate-900">{log.zoneName}</span>
                  {log.note && (
                    <span className="text-slate-600 block text-xs mt-0.5">"{log.note}"</span>
                  )}
                </div>
              </div>

              <span className="text-xs font-mono text-slate-400 shrink-0">
                {log.timestamp}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
