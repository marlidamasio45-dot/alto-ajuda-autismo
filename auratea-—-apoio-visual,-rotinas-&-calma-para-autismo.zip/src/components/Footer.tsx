import React from 'react';
import { HeartHandshake, ShieldCheck, PhoneCall, Info } from 'lucide-react';

interface Props {
  onOpenEmergency: () => void;
  onOpenSettings: () => void;
}

export const Footer: React.FC<Props> = ({ onOpenEmergency, onOpenSettings }) => {
  return (
    <footer className="mt-16 border-t border-slate-200/80 bg-white/60 py-10 text-slate-600 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                <HeartHandshake className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold text-slate-900">AuraTEA</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-md">
              Tecnologia assistiva desenhada para pessoas no Espectro Autista (TEA), suas famílias, terapeutas e educadores. Promovendo autonomia, comunicação e autorregulação sensorial.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Privacidade Total: Seus dados e rotinas ficam gravados apenas no seu aparelho.</span>
            </div>
          </div>

          {/* Useful Emergency & Support Numbers in Brazil */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Linhas de Apoio & Emergência
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600">
              <li className="flex items-center justify-between">
                <span>SAMU (Emergência Médica):</span>
                <span className="font-mono font-bold text-slate-900">192</span>
              </li>
              <li className="flex items-center justify-between">
                <span>Bombeiros:</span>
                <span className="font-mono font-bold text-slate-900">193</span>
              </li>
              <li className="flex items-center justify-between">
                <span>CVV (Apoio Emocional Gratuito):</span>
                <span className="font-mono font-bold text-slate-900">188</span>
              </li>
              <li className="flex items-center justify-between">
                <span>Disque 100 (Direitos Humanos / Acessibilidade):</span>
                <span className="font-mono font-bold text-slate-900">100</span>
              </li>
            </ul>
          </div>

          {/* Quick Rights Reference */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Direitos & Legislação (Brasil)
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Pessoas com TEA têm direito a atendimento prioritário e adaptação razoável conforme a <strong>Lei Berenice Piana (Lei nº 12.764/12)</strong> e CIPTEA (Lei nº 13.977/20).
            </p>
            <div className="pt-2">
              <button
                onClick={onOpenEmergency}
                className="text-xs font-bold text-rose-600 hover:text-rose-700 underline flex items-center gap-1"
              >
                <span>Acessar Cartão de Identificação Rápida</span>
              </button>
            </div>
          </div>

        </div>

        {/* Quiet Copyright & Credit */}
        <div className="pt-6 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            <span>© {new Date().getFullYear()} AuraTEA</span>
            <span aria-hidden="true" className="mx-2">·</span>
            <span>Apoio Inclusivo Neurodivergente</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onOpenSettings}
              className="hover:text-slate-900 transition-colors"
            >
              Ajustes de Acessibilidade
            </button>
            <span>·</span>
            <button
              onClick={onOpenEmergency}
              className="hover:text-slate-900 transition-colors"
            >
              Passaporte de Crise
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
