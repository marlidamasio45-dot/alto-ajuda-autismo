import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  RotateCcw, 
  Play, 
  Pause, 
  Timer, 
  ArrowRight, 
  Sparkles, 
  Check, 
  Trash2,
  Clock
} from 'lucide-react';
import { RoutinePreset, RoutineItem, UserPreferences, FirstThenState } from '../types/autism';
import { DEFAULT_ROUTINES } from '../data/autismData';
import { playSoftTap, playCompletionChime } from '../utils/audioEngine';

interface Props {
  preferences: UserPreferences;
}

export const VisualSchedule: React.FC<Props> = ({ preferences }) => {
  // Routine state
  const [routines, setRoutines] = useState<RoutinePreset[]>(() => {
    try {
      const saved = localStorage.getItem('auratea_routines');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return DEFAULT_ROUTINES;
  });

  const [activeRoutineId, setActiveRoutineId] = useState<string>('morning');
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskSubtitle, setNewTaskSubtitle] = useState('');
  const [newTaskEmoji, setNewTaskEmoji] = useState('⭐');
  const [newTaskTime, setNewTaskTime] = useState('');

  // First-Then state
  const [firstThen, setFirstThen] = useState<FirstThenState>(() => {
    try {
      const saved = localStorage.getItem('auratea_first_then');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      first: { title: 'Guardar os Brinquedos', emoji: '📦' },
      then: { title: 'Assistir Desenho Favorito', emoji: '📺' }
    };
  });

  const [isEditingFirstThen, setIsEditingFirstThen] = useState(false);
  const [editFirstText, setEditFirstText] = useState(firstThen.first.title);
  const [editFirstEmoji, setEditFirstEmoji] = useState(firstThen.first.emoji);
  const [editThenText, setEditThenText] = useState(firstThen.then.title);
  const [editThenEmoji, setEditThenEmoji] = useState(firstThen.then.emoji);

  // Visual Timer State
  const [timerDurationSeconds, setTimerDurationSeconds] = useState<number>(300); // 5 min default
  const [timerRemainingSeconds, setTimerRemainingSeconds] = useState<number>(300);
  const [timerIsRunning, setTimerIsRunning] = useState<boolean>(false);
  const timerIntervalRef = useRef<number | null>(null);

  const activeRoutine = routines.find(r => r.id === activeRoutineId) || routines[0];
  const completedCount = activeRoutine.items.filter(i => i.completed).length;
  const totalCount = activeRoutine.items.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Persist routines
  const saveRoutines = (updated: RoutinePreset[]) => {
    setRoutines(updated);
    localStorage.setItem('auratea_routines', JSON.stringify(updated));
  };

  const handleToggleTask = (itemId: string) => {
    playSoftTap(preferences.soundEnabled);
    const updated = routines.map(r => {
      if (r.id !== activeRoutineId) return r;
      return {
        ...r,
        items: r.items.map(item => {
          if (item.id === itemId) {
            const nextCompleted = !item.completed;
            if (nextCompleted) {
              playCompletionChime(preferences.soundEnabled);
            }
            return { ...item, completed: nextCompleted };
          }
          return item;
        })
      };
    });
    saveRoutines(updated);
  };

  const handleResetRoutine = () => {
    playSoftTap(preferences.soundEnabled);
    const updated = routines.map(r => {
      if (r.id !== activeRoutineId) return r;
      return {
        ...r,
        items: r.items.map(item => ({ ...item, completed: false }))
      };
    });
    saveRoutines(updated);
  };

  const handleAddNewTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const newItem: RoutineItem = {
      id: `task_${Date.now()}`,
      title: newTaskTitle.trim(),
      subtitle: newTaskSubtitle.trim() || undefined,
      emoji: newTaskEmoji.trim() || '⭐',
      iconName: 'Check',
      completed: false,
      timeHint: newTaskTime.trim() || undefined,
    };

    const updated = routines.map(r => {
      if (r.id !== activeRoutineId) return r;
      return {
        ...r,
        items: [...r.items, newItem]
      };
    });

    saveRoutines(updated);
    setNewTaskTitle('');
    setNewTaskSubtitle('');
    setShowAddTaskModal(false);
  };

  // First-Then Save
  const handleSaveFirstThen = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: FirstThenState = {
      first: { title: editFirstText.trim() || 'Primeiro', emoji: editFirstEmoji.trim() || '🎯' },
      then: { title: editThenText.trim() || 'Depois', emoji: editThenEmoji.trim() || '🌟' },
    };
    setFirstThen(updated);
    localStorage.setItem('auratea_first_then', JSON.stringify(updated));
    setIsEditingFirstThen(false);
    playSoftTap(preferences.soundEnabled);
  };

  // Timer logic
  useEffect(() => {
    if (timerIsRunning) {
      timerIntervalRef.current = window.setInterval(() => {
        setTimerRemainingSeconds(prev => {
          if (prev <= 1) {
            clearInterval(timerIntervalRef.current!);
            setTimerIsRunning(false);
            playCompletionChime(preferences.soundEnabled);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    }
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [timerIsRunning, preferences.soundEnabled]);

  const handleSetTimerPreset = (minutes: number) => {
    playSoftTap(preferences.soundEnabled);
    setTimerIsRunning(false);
    const secs = minutes * 60;
    setTimerDurationSeconds(secs);
    setTimerRemainingSeconds(secs);
  };

  const toggleTimer = () => {
    playSoftTap(preferences.soundEnabled);
    if (timerRemainingSeconds === 0) {
      setTimerRemainingSeconds(timerDurationSeconds);
    }
    setTimerIsRunning(prev => !prev);
  };

  const resetTimer = () => {
    playSoftTap(preferences.soundEnabled);
    setTimerIsRunning(false);
    setTimerRemainingSeconds(timerDurationSeconds);
  };

  const timerRatio = timerDurationSeconds > 0 ? timerRemainingSeconds / timerDurationSeconds : 0;
  const minutesDisplay = Math.floor(timerRemainingSeconds / 60);
  const secondsDisplay = timerRemainingSeconds % 60;
  const formattedTime = `${String(minutesDisplay).padStart(2, '0')}:${String(secondsDisplay).padStart(2, '0')}`;

  return (
    <div className="space-y-8">
      
      {/* 1. QUADRO PRIMEIRO — DEPOIS (First-Then Board) */}
      <section className="bg-white rounded-3xl border-2 border-emerald-400/50 p-5 sm:p-7 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider">
              <span>Princípio de Premack</span>
              <span>·</span>
              <span>Transições Estruturadas</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Quadro Primeiro — Depois
            </h2>
          </div>

          <button
            onClick={() => {
              playSoftTap(preferences.soundEnabled);
              setEditFirstText(firstThen.first.title);
              setEditFirstEmoji(firstThen.first.emoji);
              setEditThenText(firstThen.then.title);
              setEditThenEmoji(firstThen.then.emoji);
              setIsEditingFirstThen(true);
            }}
            className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs sm:text-sm font-semibold text-slate-700 transition-colors"
          >
            Editar Quadro
          </button>
        </div>

        {/* First - Then Visual Cards Split */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
          
          {/* PRIMEIRO */}
          <div className="p-5 rounded-2xl bg-amber-50/70 border-2 border-amber-300 flex items-center gap-4 shadow-2xs">
            <div className="w-14 h-14 rounded-2xl bg-white border border-amber-200 flex items-center justify-center text-3xl shadow-xs shrink-0 select-none">
              {firstThen.first.emoji}
            </div>
            <div className="flex-1">
              <span className="text-xs font-black uppercase text-amber-800 tracking-wider block mb-0.5">
                1. Primeiro
              </span>
              <p className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {firstThen.first.title}
              </p>
            </div>
          </div>

          {/* DEPOIS */}
          <div className="p-5 rounded-2xl bg-emerald-50/70 border-2 border-emerald-300 flex items-center gap-4 shadow-2xs">
            <div className="w-14 h-14 rounded-2xl bg-white border border-emerald-200 flex items-center justify-center text-3xl shadow-xs shrink-0 select-none">
              {firstThen.then.emoji}
            </div>
            <div className="flex-1">
              <span className="text-xs font-black uppercase text-emerald-800 tracking-wider block mb-0.5">
                2. Depois (Recompensa)
              </span>
              <p className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {firstThen.then.title}
              </p>
            </div>
          </div>

        </div>

        {/* Quick Presets for First-Then */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 mr-1">Exemplos rápidos:</span>
          {[
            { f: 'Escovar os dentes', fe: '🪥', t: 'Ler história', te: '📖' },
            { f: 'Tomar banho', fe: '🚿', t: 'Brincar no tablet', te: '📱' },
            { f: 'Comer almoço', fe: '🍛', t: 'Picolé de sobremesa', te: '🍦' },
            { f: 'Colocar sapatos', fe: '👟', t: 'Passear no parque', te: '🌳' },
          ].map((preset, i) => (
            <button
              key={i}
              onClick={() => {
                playSoftTap(preferences.soundEnabled);
                const updated: FirstThenState = {
                  first: { title: preset.f, emoji: preset.fe },
                  then: { title: preset.t, emoji: preset.te }
                };
                setFirstThen(updated);
                localStorage.setItem('auratea_first_then', JSON.stringify(updated));
              }}
              className="px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              {preset.fe} {preset.f} ➔ {preset.te} {preset.t}
            </button>
          ))}
        </div>
      </section>

      {/* 2. ROTINA DIÁRIA VISUAL & CHECKLIST */}
      <section className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Header & Presets */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
              <span>Passo a Passo Previsível</span>
              <span>·</span>
              <span>Anti-Ansiedade</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Minha Rotina Visual
            </h2>
          </div>

          {/* Routine Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto">
            {routines.map(r => (
              <button
                key={r.id}
                onClick={() => {
                  playSoftTap(preferences.soundEnabled);
                  setActiveRoutineId(r.id);
                }}
                className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  activeRoutineId === r.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>{r.emoji}</span>
                <span>{r.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Progress Strip */}
        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-900">
                Progresso: {completedCount} de {totalCount} concluídos
              </span>
              {progressPercent === 100 && (
                <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> Parabéns!
                </span>
              )}
            </div>
            {/* Visual Bar */}
            <div className="w-full sm:w-80 h-3 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddTaskModal(true)}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-2xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Tarefa</span>
            </button>
            <button
              onClick={handleResetRoutine}
              className="min-h-[40px] px-3.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-xs sm:text-sm font-medium text-slate-600 flex items-center gap-1.5 transition-colors"
              title="Reiniciar checklist do dia"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reiniciar Dia</span>
            </button>
          </div>
        </div>

        {/* Task List */}
        <div className="space-y-2.5">
          {activeRoutine.items.map((item, index) => (
            <div
              key={item.id}
              onClick={() => handleToggleTask(item.id)}
              className={`min-h-[64px] p-4 rounded-2xl border-2 transition-all flex items-center justify-between gap-4 cursor-pointer select-none ${
                item.completed
                  ? 'bg-emerald-50/40 border-emerald-300/80 opacity-75'
                  : 'bg-white border-slate-200 hover:border-emerald-300 hover:bg-slate-50/50 shadow-2xs'
              }`}
            >
              <div className="flex items-center gap-3.5 flex-1 min-w-0">
                {/* Number index */}
                <span className="w-6 text-center text-xs font-mono font-bold text-slate-400 shrink-0">
                  {String(index + 1).padStart(2, '0')}
                </span>

                {/* Emoji Icon */}
                <div className="w-11 h-11 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-2xl shrink-0">
                  {item.emoji}
                </div>

                {/* Texts */}
                <div className="min-w-0 flex-1">
                  <h4 className={`text-base font-bold leading-tight truncate ${item.completed ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                    {item.title}
                  </h4>
                  {item.subtitle && (
                    <p className="text-xs text-slate-500 truncate mt-0.5">
                      {item.subtitle}
                    </p>
                  )}
                </div>
              </div>

              {/* Time hint & Checkbox */}
              <div className="flex items-center gap-3 shrink-0">
                {item.timeHint && (
                  <span className="hidden sm:inline-flex items-center gap-1 text-xs font-mono text-slate-500 bg-slate-100 px-2 py-1 rounded-md">
                    <Clock className="w-3 h-3" />
                    {item.timeHint}
                  </span>
                )}

                <div className="w-8 h-8 rounded-full flex items-center justify-center">
                  {item.completed ? (
                    <CheckCircle2 className="w-7 h-7 text-emerald-600 fill-emerald-100" />
                  ) : (
                    <Circle className="w-7 h-7 text-slate-300 hover:text-slate-400" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. TEMPORIZADOR VISUAL REGRESSIVO (Visual Countdown Timer) */}
      <section className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-7 shadow-xs">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Left info & controls */}
          <div className="space-y-4 max-w-md w-full">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
                <span>Percepção Concreta do Tempo</span>
                <span>·</span>
                <span>Sem Ansiedade</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Temporizador Visual Regressivo
              </h3>
              <p className="text-sm text-slate-600 mt-1 leading-relaxed">
                Mostra visualmente quanto tempo falta para a próxima atividade ou descanso. O anel se esvazia gradualmente até zerar.
              </p>
            </div>

            {/* Presets */}
            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-slate-500 block">Tempo desejado:</span>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: '2 min', min: 2 },
                  { label: '5 min', min: 5 },
                  { label: '10 min', min: 10 },
                  { label: '15 min', min: 15 },
                  { label: '20 min', min: 20 },
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSetTimerPreset(item.min)}
                    className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-colors ${
                      timerDurationSeconds === item.min * 60
                        ? 'bg-slate-900 text-white shadow-2xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={toggleTimer}
                className={`min-h-[48px] px-6 py-2.5 rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all ${
                  timerIsRunning
                    ? 'bg-amber-600 hover:bg-amber-700 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                }`}
              >
                {timerIsRunning ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>Pausar</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>Iniciar Tempo</span>
                  </>
                )}
              </button>

              <button
                onClick={resetTimer}
                className="min-h-[48px] px-4 py-2.5 rounded-2xl border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold text-sm flex items-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Zerar</span>
              </button>
            </div>
          </div>

          {/* Right: Circular Graphic Timer */}
          <div className="relative w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center shrink-0">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
              {/* Background track */}
              <circle
                cx="60"
                cy="60"
                r="50"
                fill="none"
                stroke="#f1f5f9"
                strokeWidth="10"
              />
              {/* Dynamic timer circle */}
              <circle
                cx="60"
                cy="60"
                r="50"
                fill="none"
                stroke={timerRemainingSeconds === 0 ? '#10b981' : timerRatio < 0.2 ? '#f43f5e' : '#059669'}
                strokeWidth="10"
                strokeDasharray={314.16}
                strokeDashoffset={314.16 * (1 - timerRatio)}
                strokeLinecap="round"
                className="transition-all duration-1000 ease-linear"
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
              <span className="text-3xl sm:text-4xl font-mono font-black text-slate-900 tracking-tight">
                {formattedTime}
              </span>
              <span className="text-xs font-semibold text-slate-500 mt-1 uppercase tracking-wider">
                {timerRemainingSeconds === 0
                  ? 'Tempo Finalizado!'
                  : timerIsRunning
                  ? 'Contando...'
                  : 'Pausado'}
              </span>
            </div>
          </div>

        </div>
      </section>

      {/* Edit First-Then Modal */}
      {isEditingFirstThen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
              Editar Quadro Primeiro — Depois
            </h3>
            <form onSubmit={handleSaveFirstThen} className="space-y-4">
              {/* Primeiro */}
              <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200 space-y-2">
                <span className="text-xs font-bold text-amber-900 uppercase">1. Primeiro (Tarefa)</span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={editFirstEmoji}
                    onChange={e => setEditFirstEmoji(e.target.value)}
                    maxLength={3}
                    className="w-14 text-center text-2xl bg-white border border-slate-200 rounded-lg"
                  />
                  <input
                    type="text"
                    required
                    value={editFirstText}
                    onChange={e => setEditFirstText(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"
                    placeholder="Ex: Guardar os brinquedos"
                  />
                </div>
              </div>

              {/* Depois */}
              <div className="p-3.5 rounded-xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                <span className="text-xs font-bold text-emerald-900 uppercase">2. Depois (Recompensa)</span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={editThenEmoji}
                    onChange={e => setEditThenEmoji(e.target.value)}
                    maxLength={3}
                    className="w-14 text-center text-2xl bg-white border border-slate-200 rounded-lg"
                  />
                  <input
                    type="text"
                    required
                    value={editThenText}
                    onChange={e => setEditThenText(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm"
                    placeholder="Ex: Assistir desenho"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsEditingFirstThen(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl"
                >
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Task Modal */}
      {showAddTaskModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-4 pb-2 border-b border-slate-100">
              Adicionar Tarefa na Rotina
            </h3>
            <form onSubmit={handleAddNewTask} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Ícone / Emoji
                </label>
                <input
                  type="text"
                  value={newTaskEmoji}
                  onChange={e => setNewTaskEmoji(e.target.value)}
                  maxLength={3}
                  className="w-16 h-12 text-center text-2xl bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Título da Tarefa
                </label>
                <input
                  type="text"
                  required
                  value={newTaskTitle}
                  onChange={e => setNewTaskTitle(e.target.value)}
                  placeholder="Ex: Fazer dever de casa, Guardar mochila..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Instrução Curta (Opcional)
                </label>
                <input
                  type="text"
                  value={newTaskSubtitle}
                  onChange={e => setNewTaskSubtitle(e.target.value)}
                  placeholder="Ex: Com calma e silêncio"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Horário Estimado (Opcional)
                </label>
                <input
                  type="text"
                  value={newTaskTime}
                  onChange={e => setNewTaskTime(e.target.value)}
                  placeholder="Ex: 14:00"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddTaskModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl"
                >
                  Adicionar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
