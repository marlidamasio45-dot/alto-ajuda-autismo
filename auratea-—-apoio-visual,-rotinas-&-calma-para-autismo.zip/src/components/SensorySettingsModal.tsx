import React from 'react';
import { X, Check, Eye, Type, Volume2, Sparkles, Moon, Sun } from 'lucide-react';
import { UserPreferences, SensoryTheme, FontSize } from '../types/autism';
import { playSoftTap } from '../utils/audioEngine';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserPreferences;
  setPreferences: React.Dispatch<React.SetStateAction<UserPreferences>>;
}

export const SensorySettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  preferences,
  setPreferences
}) => {
  if (!isOpen) return null;

  const updatePreference = <K extends keyof UserPreferences>(key: K, value: UserPreferences[K]) => {
    playSoftTap(preferences.soundEnabled);
    setPreferences(prev => {
      const next = { ...prev, [key]: value };
      localStorage.setItem('auratea_preferences', JSON.stringify(next));
      return next;
    });
  };

  const themes: { id: SensoryTheme; label: string; desc: string; previewClass: string }[] = [
    {
      id: 'mint',
      label: 'Menta Sensorial (Padrão)',
      desc: 'Tons suaves de verde sálvia e neutros relaxantes, reduz fadiga visual.',
      previewClass: 'bg-emerald-100 border-emerald-400 text-emerald-950'
    },
    {
      id: 'sky',
      label: 'Céu Pastel',
      desc: 'Azul suave e limpo para clareza e concentração.',
      previewClass: 'bg-sky-100 border-sky-400 text-sky-950'
    },
    {
      id: 'warm',
      label: 'Âmbar Aconchego',
      desc: 'Espectro quente com baixa emissão de luz azul para o fim da tarde.',
      previewClass: 'bg-amber-100 border-amber-400 text-amber-950'
    },
    {
      id: 'dark',
      label: 'Noturno Conforto',
      desc: 'Fundo escuro suave sem preto puro agressivo para hipersensibilidade à luz.',
      previewClass: 'bg-slate-800 border-slate-600 text-slate-100'
    },
    {
      id: 'high-contrast',
      label: 'Alto Contraste',
      desc: 'Bordas nítidas e contraste estrito para máxima definição visual.',
      previewClass: 'bg-black border-yellow-400 text-yellow-300'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-900 leading-tight">
              Ajustes de Acessibilidade & Conforto Sensorial
            </h3>
            <span className="text-xs text-slate-500">
              Personalize o aplicativo para o seu bem-estar
            </span>
          </div>

          <button
            onClick={() => {
              playSoftTap(preferences.soundEnabled);
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="mt-5 space-y-6">
          
          {/* Theme Palette */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Tema de Cores Sensoriais
            </label>
            <div className="space-y-2">
              {themes.map(t => (
                <button
                  key={t.id}
                  onClick={() => updatePreference('theme', t.id)}
                  className={`w-full p-3 rounded-2xl border-2 transition-all flex items-center justify-between text-left ${
                    preferences.theme === t.id
                      ? 'border-emerald-600 bg-emerald-50/60 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-xl border flex items-center justify-center text-xs font-bold ${t.previewClass}`}>
                      Aa
                    </div>
                    <div>
                      <span className="block text-sm font-bold text-slate-900">{t.label}</span>
                      <span className="block text-xs text-slate-500">{t.desc}</span>
                    </div>
                  </div>

                  {preferences.theme === t.id && (
                    <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Font Size */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Tamanho do Texto
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'normal' as FontSize, label: 'Normal (16px)' },
                { id: 'large' as FontSize, label: 'Grande (18px)' },
                { id: 'extralarge' as FontSize, label: 'Extra Grande (21px)' },
              ].map(sz => (
                <button
                  key={sz.id}
                  onClick={() => updatePreference('fontSize', sz.id)}
                  className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-bold border-2 transition-all text-center ${
                    preferences.fontSize === sz.id
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-2xs'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  {sz.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sound FX Toggle */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-emerald-600">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <span className="text-sm font-bold text-slate-900 block">Sons de Toque e Celebração</span>
                <span className="text-xs text-slate-500 block">Sons suaves ao clicar e concluir rotinas</span>
              </div>
            </div>

            <button
              onClick={() => updatePreference('soundEnabled', !preferences.soundEnabled)}
              className={`w-12 h-7 rounded-full transition-colors relative p-0.5 ${
                preferences.soundEnabled ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                  preferences.soundEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Reduced Motion Toggle */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-teal-600">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-sm font-bold text-slate-900 block">Reduzir Animações</span>
                <span className="text-xs text-slate-500 block">Evita desconforto com movimentos visuais</span>
              </div>
            </div>

            <button
              onClick={() => updatePreference('reducedMotion', !preferences.reducedMotion)}
              className={`w-12 h-7 rounded-full transition-colors relative p-0.5 ${
                preferences.reducedMotion ? 'bg-emerald-600' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                  preferences.reducedMotion ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={() => {
              playSoftTap(preferences.soundEnabled);
              onClose();
            }}
            className="min-h-[44px] px-6 py-2 bg-slate-900 text-white font-bold text-sm rounded-xl hover:bg-slate-800 transition-colors"
          >
            Concluir
          </button>
        </div>

      </div>
    </div>
  );
};
