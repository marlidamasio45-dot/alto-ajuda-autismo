import { PictogramCard, RoutinePreset, SocialStory, RegulationZoneInfo, EmergencyPassport } from '../types/autism';

export const DEFAULT_PICTOGRAMS: PictogramCard[] = [
  // Básicos & Expressão
  { id: 'p_want', label: 'Eu Quero', speechText: 'Eu quero', category: 'basic', emoji: '👉', bgTint: 'bg-emerald-50 text-emerald-950', borderTint: 'border-emerald-200' },
  { id: 'p_help', label: 'Preciso de Ajuda', speechText: 'Por favor, preciso de ajuda', category: 'basic', emoji: '🆘', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_yes', label: 'Sim', speechText: 'Sim', category: 'basic', emoji: '👍', bgTint: 'bg-emerald-50 text-emerald-950', borderTint: 'border-emerald-200' },
  { id: 'p_no', label: 'Não', speechText: 'Não', category: 'basic', emoji: '✋', bgTint: 'bg-rose-50 text-rose-950', borderTint: 'border-rose-200' },
  { id: 'p_more', label: 'Mais', speechText: 'Quero mais', category: 'basic', emoji: '➕', bgTint: 'bg-sky-50 text-sky-950', borderTint: 'border-sky-200' },
  { id: 'p_finish', label: 'Acabou', speechText: 'Já acabou, chega', category: 'basic', emoji: '🛑', bgTint: 'bg-slate-100 text-slate-900', borderTint: 'border-slate-300' },
  { id: 'p_wait', label: 'Esperar', speechText: 'Preciso esperar', category: 'basic', emoji: '⏳', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_thanks', label: 'Obrigado', speechText: 'Muito obrigado', category: 'basic', emoji: '🙏', bgTint: 'bg-purple-50 text-purple-950', borderTint: 'border-purple-200' },
  { id: 'p_rest', label: 'Descansar', speechText: 'Quero descansar', category: 'basic', emoji: '🛋️', bgTint: 'bg-indigo-50 text-indigo-950', borderTint: 'border-indigo-200' },
  { id: 'p_water', label: 'Água', speechText: 'Quero beber água', category: 'food', emoji: '💧', bgTint: 'bg-sky-50 text-sky-950', borderTint: 'border-sky-200' },
  { id: 'p_toilet', label: 'Banheiro', speechText: 'Preciso ir ao banheiro', category: 'body', emoji: '🚻', bgTint: 'bg-teal-50 text-teal-950', borderTint: 'border-teal-200' },

  // Alimentação & Bebidas
  { id: 'p_eat', label: 'Comer', speechText: 'Quero comer', category: 'food', emoji: '🍽️', bgTint: 'bg-orange-50 text-orange-950', borderTint: 'border-orange-200' },
  { id: 'p_juice', label: 'Suco', speechText: 'Quero um suco', category: 'food', emoji: '🧃', bgTint: 'bg-orange-50 text-orange-950', borderTint: 'border-orange-200' },
  { id: 'p_fruit', label: 'Fruta', speechText: 'Quero uma fruta', category: 'food', emoji: '🍎', bgTint: 'bg-red-50 text-red-950', borderTint: 'border-red-200' },
  { id: 'p_bread', label: 'Pão', speechText: 'Quero comer pão', category: 'food', emoji: '🍞', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_milk', label: 'Leite', speechText: 'Quero um copo de leite', category: 'food', emoji: '🥛', bgTint: 'bg-sky-50 text-sky-950', borderTint: 'border-sky-200' },
  { id: 'p_lunch', label: 'Almoço', speechText: 'Hora do almoço', category: 'food', emoji: '🍛', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_cookie', label: 'Biscoito', speechText: 'Quero biscoito', category: 'food', emoji: '🍪', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_icecream', label: 'Picolé / Sorvete', speechText: 'Quero sorvete', category: 'food', emoji: '🍦', bgTint: 'bg-pink-50 text-pink-950', borderTint: 'border-pink-200' },

  // Emoções & Sensações
  { id: 'p_happy', label: 'Estou Feliz', speechText: 'Eu estou feliz', category: 'emotions', emoji: '😊', bgTint: 'bg-emerald-50 text-emerald-950', borderTint: 'border-emerald-200' },
  { id: 'p_calm', label: 'Estou Calmo', speechText: 'Eu estou calmo e tranquilo', category: 'emotions', emoji: '😌', bgTint: 'bg-teal-50 text-teal-950', borderTint: 'border-teal-200' },
  { id: 'p_sad', label: 'Estou Triste', speechText: 'Eu estou me sentindo triste', category: 'emotions', emoji: '😢', bgTint: 'bg-blue-50 text-blue-950', borderTint: 'border-blue-200' },
  { id: 'p_angry', label: 'Bravo / Irritado', speechText: 'Estou bravo e irritado', category: 'emotions', emoji: '😠', bgTint: 'bg-red-50 text-red-950', borderTint: 'border-red-200' },
  { id: 'p_tired', label: 'Cansado', speechText: 'Estou muito cansado', category: 'emotions', emoji: '🥱', bgTint: 'bg-purple-50 text-purple-950', borderTint: 'border-purple-200' },
  { id: 'p_pain', label: 'Com Dor', speechText: 'Estou sentindo dor', category: 'emotions', emoji: '🤕', bgTint: 'bg-rose-50 text-rose-950', borderTint: 'border-rose-200' },
  { id: 'p_loud', label: 'Muito Barulho', speechText: 'O barulho está muito alto, me incomoda', category: 'emotions', emoji: '🙉', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_headphones', label: 'Quero Fone', speechText: 'Por favor, me dê meus fones de ouvido', category: 'emotions', emoji: '🎧', bgTint: 'bg-indigo-50 text-indigo-950', borderTint: 'border-indigo-200' },
  { id: 'p_light', label: 'Luz Forte', speechText: 'A luz está muito forte nos meus olhos', category: 'emotions', emoji: '☀️', bgTint: 'bg-yellow-50 text-yellow-950', borderTint: 'border-yellow-200' },
  { id: 'p_notouch', label: 'Não Me Toque', speechText: 'Por favor, não toque em mim agora', category: 'emotions', emoji: '🚫', bgTint: 'bg-rose-50 text-rose-950', borderTint: 'border-rose-200' },
  { id: 'p_hug', label: 'Quero Abraço', speechText: 'Quero um abraço com carinho', category: 'emotions', emoji: '🫂', bgTint: 'bg-violet-50 text-violet-950', borderTint: 'border-violet-200' },

  // Higiene & Corpo
  { id: 'p_wash_hands', label: 'Lavar as Mãos', speechText: 'Vou lavar as minhas mãos', category: 'body', emoji: '🧼', bgTint: 'bg-cyan-50 text-cyan-950', borderTint: 'border-cyan-200' },
  { id: 'p_teeth', label: 'Escovar Dentes', speechText: 'Hora de escovar os dentes', category: 'body', emoji: '🪥', bgTint: 'bg-sky-50 text-sky-950', borderTint: 'border-sky-200' },
  { id: 'p_shower', label: 'Tomar Banho', speechText: 'Vou tomar banho', category: 'body', emoji: '🚿', bgTint: 'bg-blue-50 text-blue-950', borderTint: 'border-blue-200' },
  { id: 'p_clothes', label: 'Trocar Roupa', speechText: 'Preciso trocar de roupa', category: 'body', emoji: '👕', bgTint: 'bg-emerald-50 text-emerald-950', borderTint: 'border-emerald-200' },
  { id: 'p_sleep', label: 'Dormir', speechText: 'Quero ir dormir', category: 'body', emoji: '🛏️', bgTint: 'bg-indigo-50 text-indigo-950', borderTint: 'border-indigo-200' },

  // Atividades & Lazer
  { id: 'p_play', label: 'Brincar', speechText: 'Quero brincar', category: 'activities', emoji: '🧸', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_tablet', label: 'Tablet / Celular', speechText: 'Quero usar o tablet', category: 'activities', emoji: '📱', bgTint: 'bg-purple-50 text-purple-950', borderTint: 'border-purple-200' },
  { id: 'p_music', label: 'Ouvir Música', speechText: 'Quero ouvir música', category: 'activities', emoji: '🎵', bgTint: 'bg-pink-50 text-pink-950', borderTint: 'border-pink-200' },
  { id: 'p_draw', label: 'Desenhar / Pintar', speechText: 'Quero desenhar e pintar', category: 'activities', emoji: '🖍️', bgTint: 'bg-rose-50 text-rose-950', borderTint: 'border-rose-200' },
  { id: 'p_blocks', label: 'Montar Blocos', speechText: 'Quero brincar de montar peças', category: 'activities', emoji: '🧱', bgTint: 'bg-emerald-50 text-emerald-950', borderTint: 'border-emerald-200' },
  { id: 'p_walk', label: 'Passear', speechText: 'Quero passear um pouco', category: 'activities', emoji: '🚶', bgTint: 'bg-lime-50 text-lime-950', borderTint: 'border-lime-200' },

  // Lugares & Social
  { id: 'p_home', label: 'Ir para Casa', speechText: 'Quero ir para casa', category: 'places', emoji: '🏠', bgTint: 'bg-blue-50 text-blue-950', borderTint: 'border-blue-200' },
  { id: 'p_school', label: 'Escola', speechText: 'Hora de ir para a escola', category: 'places', emoji: '🏫', bgTint: 'bg-amber-50 text-amber-950', borderTint: 'border-amber-200' },
  { id: 'p_park', label: 'Parque', speechText: 'Vamos ao parque', category: 'places', emoji: '🌳', bgTint: 'bg-emerald-50 text-emerald-950', borderTint: 'border-emerald-200' },
  { id: 'p_car', label: 'Carro', speechText: 'Entrar no carro', category: 'places', emoji: '🚗', bgTint: 'bg-sky-50 text-sky-950', borderTint: 'border-sky-200' },
  { id: 'p_mom', label: 'Mamãe', speechText: 'Quero a mamãe', category: 'social', emoji: '👩', bgTint: 'bg-pink-50 text-pink-950', borderTint: 'border-pink-200' },
  { id: 'p_dad', label: 'Papai', speechText: 'Quero o papai', category: 'social', emoji: '👨', bgTint: 'bg-blue-50 text-blue-950', borderTint: 'border-blue-200' },
];

export const DEFAULT_ROUTINES: RoutinePreset[] = [
  {
    id: 'morning',
    name: 'Rotina da Manhã',
    description: 'Começando o dia com tranquilidade e passos claros.',
    emoji: '🌅',
    items: [
      { id: 'm1', title: 'Acordar e Espreguiçar', subtitle: 'Respirar fundo 3 vezes', iconName: 'Sun', emoji: '☀️', completed: false, timeHint: '07:30', durationMinutes: 5 },
      { id: 'm2', title: 'Usar o Banheiro', subtitle: 'Fazer xixi', iconName: 'Bath', emoji: '🚻', completed: false, timeHint: '07:35', durationMinutes: 5 },
      { id: 'm3', title: 'Lavar as Mãos e Rosto', subtitle: 'Água fresca e toalha', iconName: 'Droplets', emoji: '🧼', completed: false, timeHint: '07:40', durationMinutes: 5 },
      { id: 'm4', title: 'Vestir a Roupa', subtitle: 'Roupa confortável do dia', iconName: 'Shirt', emoji: '👕', completed: false, timeHint: '07:45', durationMinutes: 10 },
      { id: 'm5', title: 'Tomar Café da Manhã', subtitle: 'Comida gostosa e nutritiva', iconName: 'Utensils', emoji: '🍞', completed: false, timeHint: '08:00', durationMinutes: 15 },
      { id: 'm6', title: 'Escovar os Dentes', subtitle: 'Dentes limpos e brilhantes', iconName: 'Sparkles', emoji: '🪥', completed: false, timeHint: '08:20', durationMinutes: 5 },
      { id: 'm7', title: 'Organizar a Mochila', subtitle: 'Conferir fones e brinquedo favorito', iconName: 'Backpack', emoji: '🎒', completed: false, timeHint: '08:30', durationMinutes: 5 },
    ]
  },
  {
    id: 'afternoon',
    name: 'Pós-Escola & Tarde',
    description: 'Transição suave ao voltar para o aconchego de casa.',
    emoji: '🌤️',
    items: [
      { id: 'a1', title: 'Chegar em Casa e Tirar os Sapatos', subtitle: 'Sentir os pés livres', iconName: 'Home', emoji: '👟', completed: false, timeHint: '12:30', durationMinutes: 5 },
      { id: 'a2', title: 'Lavar as Mãos com Sabão', subtitle: 'Limpar bem os dedinhos', iconName: 'Droplets', emoji: '🧼', completed: false, timeHint: '12:35', durationMinutes: 5 },
      { id: 'a3', title: 'Trocar para Roupa de Casa', subtitle: 'Roupa macia e sem etiquetas', iconName: 'Shirt', emoji: '👕', completed: false, timeHint: '12:40', durationMinutes: 5 },
      { id: 'a4', title: 'Almoço em Paz', subtitle: 'Comer no seu ritmo', iconName: 'Utensils', emoji: '🍛', completed: false, timeHint: '13:00', durationMinutes: 20 },
      { id: 'a5', title: 'Tempo Livre de Descompressão', subtitle: 'Descansar sem barulho, tablet ou blocos', iconName: 'Headphones', emoji: '🎧', completed: false, timeHint: '13:30', durationMinutes: 30 },
      { id: 'a6', title: 'Lanchinho da Tarde', subtitle: 'Fruta ou biscoito', iconName: 'Apple', emoji: '🍎', completed: false, timeHint: '16:00', durationMinutes: 15 },
    ]
  },
  {
    id: 'night',
    name: 'Rotina Noturna & Sono',
    description: 'Desacelerando os sentidos para um sono reparador.',
    emoji: '🌙',
    items: [
      { id: 'n1', title: 'Guardar Brinquedos', subtitle: 'Cada coisa no seu lugar', iconName: 'Box', emoji: '📦', completed: false, timeHint: '19:30', durationMinutes: 10 },
      { id: 'n2', title: 'Tomar Banho Morno', subtitle: 'Água agradável e relaxante', iconName: 'Bath', emoji: '🛁', completed: false, timeHint: '19:45', durationMinutes: 15 },
      { id: 'n3', title: 'Vestir Pijama Confortável', subtitle: 'Pijama limpinho e macio', iconName: 'Moon', emoji: '✨', completed: false, timeHint: '20:05', durationMinutes: 5 },
      { id: 'n4', title: 'Jantar', subtitle: 'Refeição leve', iconName: 'Utensils', emoji: '🍲', completed: false, timeHint: '20:15', durationMinutes: 20 },
      { id: 'n5', title: 'Escovar os Dentes', subtitle: 'Cuidado final dos dentes', iconName: 'Sparkles', emoji: '🪥', completed: false, timeHint: '20:40', durationMinutes: 5 },
      { id: 'n6', title: 'Diminuir as Luzes', subtitle: 'Luz fraca e som ambiente', iconName: 'Lamp', emoji: '🕯️', completed: false, timeHint: '20:50', durationMinutes: 5 },
      { id: 'n7', title: 'História ou Música Calma', subtitle: 'Respirar e dormir bem', iconName: 'Book', emoji: '📖', completed: false, timeHint: '21:00', durationMinutes: 15 },
    ]
  }
];

export const REGULATION_ZONES: RegulationZoneInfo[] = [
  {
    zone: 'green',
    name: 'Zona Verde',
    feeling: 'Calmo, Conectado & Focado',
    colorName: 'Verde',
    bgClass: 'bg-emerald-50 text-emerald-950',
    borderClass: 'border-emerald-200',
    textClass: 'text-emerald-700',
    icon: 'CheckCircle2',
    description: 'Meu corpo e mente estão tranquilos. Me sinto confortável, pronto para aprender, conversar e me divertir.',
    recommendedStrategies: [
      { title: 'Manter a Boa Energia', actionText: 'Continue fazendo o que gosta e aproveite o momento tranquilo.', emoji: '✨' },
      { title: 'Aprender Algo Novo', actionText: 'Ótimo momento para ler, desenhar ou realizar tarefas importantes.', emoji: '📚' },
      { title: 'Compartilhar Sorrisos', actionText: 'Converse com quem está perto de você.', emoji: '💬' }
    ]
  },
  {
    zone: 'yellow',
    name: 'Zona Amarela',
    feeling: 'Alerta, Inquieto ou Frustrado',
    colorName: 'Amarelo',
    bgClass: 'bg-amber-50 text-amber-950',
    borderClass: 'border-amber-200',
    textClass: 'text-amber-700',
    icon: 'AlertCircle',
    description: 'Começo a sentir desconforto: barulhos me incomodam, sinto o corpo agitado, fome, cansaço ou pequenas frustrações.',
    recommendedStrategies: [
      { title: 'Pausa Sensorial de 5 Minutos', actionText: 'Pare o que estiver fazendo e descanse em um canto mais quieto.', emoji: '⏸️' },
      { title: 'Colocar Fones de Ouvido', actionText: 'Abafar sons do ambiente para aliviar a audição.', emoji: '🎧' },
      { title: 'Beber um Copo d’Água Gelada', actionText: 'A sensação da água fria ajuda a ancorar o corpo.', emoji: '💧' },
      { title: 'Respiração Flor e Vela', actionText: 'Cheirar a flor por 4 segundos e assoprar a vela por 4 segundos.', emoji: '🌸' }
    ]
  },
  {
    zone: 'orange',
    name: 'Zona Laranja',
    feeling: 'Sobrecarga Sensorial Alta / Ansiedade Forte',
    colorName: 'Laranja',
    bgClass: 'bg-orange-50 text-orange-950',
    borderClass: 'border-orange-200',
    textClass: 'text-orange-700',
    icon: 'Flame',
    description: 'Estímulos demais! Sinto que estou perdendo a paciência, meu coração bate mais rápido, a luz queima meus olhos ou quero fugir.',
    recommendedStrategies: [
      { title: 'Ir para o Espaço de Calma', actionText: 'Sair imediatamente do ambiente agitado para um quarto silencioso.', emoji: '🛋️' },
      { title: 'Diminuir Estímulos', actionText: 'Apagar luzes fortes, fechar janelas e pedir silêncio.', emoji: '💡' },
      { title: 'Pressão Profunda Confortável', actionText: 'Usar cobertor pesado, almofada ou abraço firme se a pessoa consentir.', emoji: '🧸' },
      { title: 'Fidget ou Objeto de Apego', actionText: 'Apertar uma massinha ou bolinha sensorial para descarregar a tensão.', emoji: '🟢' }
    ]
  },
  {
    zone: 'red',
    name: 'Zona Vermelha',
    feeling: 'Crise / Meltdown / Sobrecarga Extrema',
    colorName: 'Vermelho',
    bgClass: 'bg-rose-50 text-rose-950',
    borderClass: 'border-rose-200',
    textClass: 'text-rose-700',
    icon: 'ShieldAlert',
    description: 'Meu cérebro entrou em modo de defesa total (meltdown ou shutdown). Não consigo falar nem raciocinar agora.',
    recommendedStrategies: [
      { title: 'Segurança em Primeiro Lugar', actionText: 'Retire objetos perigosos e garanta que ninguém fique em volta olhando.', emoji: '🛡️' },
      { title: 'Silêncio Absoluto & Sem Cobranças', actionText: 'Não faça perguntas nem repreenda. Frases curtas: "Você está seguro".', emoji: '🤫' },
      { title: 'Não Tocar sem Consentimento', actionText: 'Toques inesperados durante a crise aumentam a dor sensorial.', emoji: '🚫' },
      { title: 'Aguardar o Tempo do Cérebro', actionText: 'O sistema nervoso precisa de 15 a 30 minutos para esfriar. Apenas proteja.', emoji: '⏳' }
    ]
  }
];

export const SOCIAL_STORIES: SocialStory[] = [
  {
    id: 'dentist',
    title: 'Indo ao Dentista',
    summary: 'Entenda como funciona a visita e como cuidar do seu sorriso sem medo.',
    category: 'Saúde & Cuidados',
    emoji: '🦷',
    steps: [
      {
        title: '1. O que é o Dentista?',
        description: 'O dentista é um médico especialista em cuidar dos dentes. Ele vai olhar se meus dentes estão fortes e limpinhos.',
        emoji: '🩺',
        tips: 'Posso levar meus fones de ouvido para abafar o barulho dos aparelhos.'
      },
      {
        title: '2. Sentando na Cadeira Mágica',
        description: 'A cadeira sobe e deita como um carrinho suave. Uma luz vai acender acima para o dentista enxergar bem.',
        emoji: '💺',
        tips: 'Se a luz incomodar, posso usar óculos de sol ou fechar os olhos.'
      },
      {
        title: '3. Abrindo a Boca',
        description: 'O dentista vai pedir para abrir a boca como um leão. Ele usa um espelhinho bem pequenininho para olhar atrás dos dentes.',
        emoji: '🦁',
        tips: 'O espelhinho não dói, só reflete a luz.'
      },
      {
        title: '4. Se eu precisar de uma pausa',
        description: 'Eu posso combinar um sinal com a minha mão! Se eu levantar a mão, o dentista para na mesma hora para eu respirar.',
        emoji: '✋',
        tips: 'Eu tenho o controle e posso pedir pausa a qualquer momento.'
      },
      {
        title: '5. Parabéns! Missão cumprida',
        description: 'A visita acabou, enxáguo a boca com água e meus dentes estão protegidos. Posso receber um carinho ou escolher um prêmio.',
        emoji: '🌟',
        tips: 'Comemorei minha coragem!'
      }
    ]
  },
  {
    id: 'haircut',
    title: 'Cortando o Cabelo',
    summary: 'Passo a passo confortável para o corte de cabelo.',
    category: 'Sensorial & Higiene',
    emoji: '✂️',
    steps: [
      {
        title: '1. Por que cortamos o cabelo?',
        description: 'O cabelo cresce com o tempo e pode começar a cair nos olhos ou esquentar a cabeça. Cortar deixa a cabeça leve e fresca.',
        emoji: '💇',
        tips: 'Cabelo não tem nervos, o corte em si não dói.'
      },
      {
        title: '2. A Capa Protetora',
        description: 'O cabeleireiro coloca uma capa para que os cabelinhos cortados não entrem na nossa roupa.',
        emoji: '🦹',
        tips: 'Se o colarinho incomodar meu pescoço, posso pedir para colocar uma toalhinha macia.'
      },
      {
        title: '3. A Tesoura e a Máquina',
        description: 'A tesoura faz um som de "tchac-tchac". Se usarem a máquina, ela faz um barulhinho de abelha e vibra um pouco.',
        emoji: '🐝',
        tips: 'Posso pedir para o cabeleireiro me mostrar a tesoura antes de começar.'
      },
      {
        title: '4. Durante o Corte',
        description: 'Posso segurar meu brinquedo favorito ou assistir a um vídeo no celular para o tempo passar rapidinho.',
        emoji: '📱',
        tips: 'Fico com a cabeça parada por alguns minutos.'
      },
      {
        title: '5. Tirando os cabelinhos soltos',
        description: 'Um pincel macio ou secador morno vai tirar os fios do pescoço. Pronto! Ficou ótimo e muito confortável.',
        emoji: '✨',
        tips: 'Posso tomar um banho gostoso depois para tirar qualquer farelo.'
      }
    ]
  },
  {
    id: 'plan_changes',
    title: 'Quando o Plano Muda',
    summary: 'Aprenda a lidar com imprevistos e mudanças na rotina com segurança.',
    category: 'Emoções & Flexibilidade',
    emoji: '🔄',
    steps: [
      {
        title: '1. Planos podem mudar',
        description: 'Às vezes chove e não dá para ir ao parque, ou um lugar está fechado. Isso acontece com todo mundo.',
        emoji: '🌧️',
        tips: 'Mudar de plano não é culpa de ninguém.'
      },
      {
        title: '2. É normal sentir incômodo',
        description: 'Quando as coisas não saem como planejado, posso sentir raiva, susto ou frustração no peito.',
        emoji: '😣',
        tips: 'Meus sentimentos são válidos. Posso dizer: "Fiquei chateado com essa mudança".'
      },
      {
        title: '3. A Pausa de 3 Respirações',
        description: 'Puxo o ar pelo nariz bem devagar, seguro um instante e solto pela boca. Meu corpo começa a se acalmar.',
        emoji: '🌬️',
        tips: 'Respirar fundo avisa ao cérebro que continuo seguro.'
      },
      {
        title: '4. Criando o Plano B',
        description: 'Junto com um adulto ou amigo, penso em uma nova atividade divertida: "Se não podemos ir ao parque, o que podemos fazer em casa?"',
        emoji: '💡',
        tips: 'O Plano B também pode ser muito legal e surpreendente.'
      },
      {
        title: '5. Parabéns pela Flexibilidade',
        description: 'Ser flexível é um superpoder que cresce toda vez que tentamos algo novo.',
        emoji: '🦸',
        tips: 'Tenho orgulho de conseguir me adaptar.'
      }
    ]
  },
  {
    id: 'sensory_overload',
    title: 'Quando o Barulho Fica Alto',
    summary: 'O que fazer quando os sons ao redor estão machucando seus ouvidos.',
    category: 'Sensorial & Defesa',
    emoji: '🎧',
    steps: [
      {
        title: '1. Reconhecendo o Incômodo',
        description: 'Lugares com muitas vozes, buzinas, sirenes ou música alta podem causar dor de cabeça ou irritação.',
        emoji: '📢',
        tips: 'Meu ouvido é muito sensível e isso é comum no espectro autista.'
      },
      {
        title: '2. Usar Meus Protetores',
        description: 'Pego meus fones antirruído ou tampões e coloco nos ouvidos. O volume do mundo diminui na hora.',
        emoji: '🎧',
        tips: 'Não preciso ter vergonha de usar fones em público.'
      },
      {
        title: '3. Avisar quem está comigo',
        description: 'Posso usar o aplicativo e mostrar a prancha: "MUITO BARULHO" ou "PRECISO DE SILÊNCIO".',
        emoji: '📱',
        tips: 'Quem está comigo vai me entender e me ajudar.'
      },
      {
        title: '4. Procurar um Cantinho Calmo',
        description: 'Caminhamos até uma área mais tranquila, um corredor vazio, um carro ou ao ar livre.',
        emoji: '🌿',
        tips: 'Poucos minutos em silêncio recarregam minha bateria.'
      }
    ]
  }
];

export const DEFAULT_EMERGENCY_PASSPORT: EmergencyPassport = {
  personName: 'Alexandre Souza',
  preferredName: 'Ale',
  birthYearOrAge: '14 anos',
  isVerbal: 'semi-verbal',
  communicationTip: 'Em momentos de estresse fico não-verbal. Compreendo tudo o que você fala. Fale em frases curtas, tom calmo e direto.',
  emergencyContactName: 'Mariana Souza (Mãe)',
  emergencyPhone: '(11) 98765-4321',
  doctorOrCaregiverPhone: '(11) 91234-5678',
  sensoryTriggers: [
    'Barulhos agudos ou sirenes sem aviso',
    'Toques físicos inesperados de estranhos',
    'Luzes estroboscópicas / fluorescentes piscando',
    'Multidões e pessoas falando ao mesmo tempo'
  ],
  calmingTips: [
    'Ofereça meus fones de ouvido que estão na mochila',
    'Conduza-me para um local com menos luz e silêncio',
    'Dê-me espaço físico, não tente me segurar se eu estiver seguro',
    'Ofereça água gelada em silêncio'
  ],
  safeSpecialInterests: 'Gosto de falar sobre planetas do sistema solar e trens.',
  hasMedicalNotes: 'Não tenho alergias alimentares graves. Uso cordão com identificação de TEA.'
};
