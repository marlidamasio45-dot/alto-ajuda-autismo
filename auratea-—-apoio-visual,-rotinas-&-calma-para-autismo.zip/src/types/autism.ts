// Types for AuraTEA application

export type SensoryTheme = 'mint' | 'sky' | 'warm' | 'dark' | 'high-contrast';
export type FontSize = 'normal' | 'large' | 'extralarge';

export interface UserPreferences {
  theme: SensoryTheme;
  fontSize: FontSize;
  soundEnabled: boolean;
  reducedMotion: boolean;
}

export type PictogramCategory = 
  | 'basic'       // Necessidades & Expressão rápida
  | 'food'        // Alimentação & Bebidas
  | 'emotions'    // Emoções & Sensações
  | 'body'        // Higiene & Corpo
  | 'activities'  // Brincadeiras & Tarefas
  | 'places'      // Lugares
  | 'social';     // Pessoas & Social

export interface PictogramCard {
  id: string;
  label: string;
  speechText?: string;
  category: PictogramCategory;
  emoji: string;
  bgTint: string;
  borderTint: string;
  isCustom?: boolean;
}

export interface RoutineItem {
  id: string;
  title: string;
  subtitle?: string;
  iconName: string;
  emoji: string;
  completed: boolean;
  timeHint?: string;
  durationMinutes?: number;
}

export interface RoutinePreset {
  id: string;
  name: string;
  description: string;
  emoji: string;
  items: RoutineItem[];
}

export interface FirstThenState {
  first: {
    title: string;
    emoji: string;
    category?: string;
  };
  then: {
    title: string;
    emoji: string;
    category?: string;
  };
}

export interface SocialStoryStep {
  title: string;
  description: string;
  emoji: string;
  tips?: string;
}

export interface SocialStory {
  id: string;
  title: string;
  summary: string;
  category: string;
  emoji: string;
  steps: SocialStoryStep[];
}

export type RegulationZone = 'green' | 'yellow' | 'orange' | 'red';

export interface RegulationZoneInfo {
  zone: RegulationZone;
  name: string;
  feeling: string;
  colorName: string;
  bgClass: string;
  borderClass: string;
  textClass: string;
  icon: string;
  description: string;
  recommendedStrategies: {
    title: string;
    actionText: string;
    emoji: string;
  }[];
}

export interface EmergencyPassport {
  personName: string;
  preferredName?: string;
  birthYearOrAge: string;
  isVerbal: 'verbal' | 'semi-verbal' | 'non-verbal';
  communicationTip: string;
  emergencyContactName: string;
  emergencyPhone: string;
  doctorOrCaregiverPhone?: string;
  sensoryTriggers: string[];
  calmingTips: string[];
  safeSpecialInterests: string;
  hasMedicalNotes: string;
}
