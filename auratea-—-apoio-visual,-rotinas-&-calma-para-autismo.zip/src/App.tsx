import React, { useState, useEffect } from 'react';
import { UserPreferences, SensoryTheme, FontSize } from './types/autism';
import { SensoryHeader } from './components/SensoryHeader';
import { AACBoard } from './components/AACBoard';
import { VisualSchedule } from './components/VisualSchedule';
import { CalmSpace } from './components/CalmSpace';
import { EmotionThermometer } from './components/EmotionThermometer';
import { SocialStoriesView } from './components/SocialStoriesView';
import { EmergencyCardModal } from './components/EmergencyCardModal';
import { SensorySettingsModal } from './components/SensorySettingsModal';
import { Footer } from './components/Footer';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('aac');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);

  const [preferences, setPreferences] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem('auratea_preferences');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      theme: 'mint',
      fontSize: 'normal',
      soundEnabled: true,
      reducedMotion: false,
    };
  });

  // Theme wrapper classes
  const getThemeWrapperClass = (theme: SensoryTheme): string => {
    switch (theme) {
      case 'sky':
        return 'bg-sky-50/40 text-slate-900 selection:bg-sky-200';
      case 'warm':
        return 'bg-amber-50/40 text-stone-900 selection:bg-amber-200';
      case 'dark':
        return 'bg-slate-950 text-slate-100 selection:bg-slate-700';
      case 'high-contrast':
        return 'bg-neutral-950 text-yellow-300 selection:bg-yellow-400 selection:text-black';
      case 'mint':
      default:
        return 'bg-slate-50 text-slate-900 selection:bg-emerald-200';
    }
  };

  const getFontSizeClass = (size: FontSize): string => {
    switch (size) {
      case 'large':
        return 'text-[17px]';
      case 'extralarge':
        return 'text-[19px]';
      case 'normal':
      default:
        return 'text-[15px]';
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 flex flex-col ${getThemeWrapperClass(preferences.theme)} ${getFontSizeClass(preferences.fontSize)} ${preferences.reducedMotion ? 'motion-reduce' : ''}`}>
      
      {/* Top Bar Contract Navigation */}
      <SensoryHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        preferences={preferences}
        setPreferences={setPreferences}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'aac' && (
          <AACBoard preferences={preferences} />
        )}

        {activeTab === 'routines' && (
          <VisualSchedule preferences={preferences} />
        )}

        {activeTab === 'calm' && (
          <CalmSpace preferences={preferences} />
        )}

        {activeTab === 'emotions' && (
          <EmotionThermometer
            preferences={preferences}
            onNavigateToCalm={() => setActiveTab('calm')}
          />
        )}

        {activeTab === 'stories' && (
          <SocialStoriesView preferences={preferences} />
        )}
      </main>

      {/* Modal Dialogs */}
      <EmergencyCardModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        preferences={preferences}
      />

      <SensorySettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        preferences={preferences}
        setPreferences={setPreferences}
      />

      {/* Footer */}
      <Footer
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />
      
    </div>
  );
}

export default App;
